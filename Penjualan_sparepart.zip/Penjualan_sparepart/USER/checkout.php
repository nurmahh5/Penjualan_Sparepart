<?php
session_start();

// Include file koneksi database
include 'koneksi.php'; // Sesuaikan dengan nama file koneksi Anda

// Jika tidak ada session pelanggan (belum login)
if (!isset($_SESSION["user_id"])) {
    // Diarahkan ke login.php
    echo "<script>alert('Silahkan login!')</script>";
    echo "<script>location='masuk.php';</script>";
    exit();
}

// Ambil ID pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Ambil data pengguna dari database
$queryUser = "SELECT * FROM tabel_pelanggan WHERE id_pelanggan = ?";
$stmtUser = $koneksi->prepare($queryUser);
$stmtUser->bind_param("i", $user_id);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();

if ($resultUser->num_rows === 1) {
    $rowUser = $resultUser->fetch_assoc();
    $nama_pelanggan = $rowUser['nama_pelanggan'];
    $email = $rowUser['email'];
    $no_telp = $rowUser['no_telp'];
    $alamat = $rowUser['alamat'];
} else {
    echo "Data pengguna tidak ditemukan.";
    exit();
}

$stmtUser->close();

if (isset($_POST["checkout"])) {
    $alamat_pengiriman = $_POST['alamat_pengiriman'];
    $provinsi = $_POST['provinsi'];
    $distrik = $_POST['distrik'];
    $tipe = $_POST['tipe'];
    $kodepos = $_POST['kodepos'];
    $ekspedisi = $_POST['ekspedisi'];
    $paket = $_POST['paket'];
    $ongkir = $_POST['ongkir'];
    $estimasi = $_POST['estimasi'];
    $catatan = $_POST['catatan'];

    if (empty($alamat_pengiriman) || empty($provinsi) || empty($distrik) || empty($tipe) || empty($kodepos) || empty($ekspedisi) || empty($paket) || empty($ongkir) || empty($estimasi)) {
        echo "<script>alert('Semua kolom harus diisi!')</script>";
        exit();
    }

    // Tetapkan metode pembayaran menjadi "Online Payment"
    $metode_pembayaran = 'Online Payment';

    // Hitung total belanja
    $totalBelanja = 0;
    $totalBerat = 0;

    foreach ($_SESSION['cart'] as $product) {
        $totalBelanja += $product['price'] * $product['quantity'];

        // Ambil berat produk dari database
        $queryBerat = "SELECT berat_produk FROM tb_sparepart WHERE id_produk = ?";
        $stmtBerat = $koneksi->prepare($queryBerat);
        $stmtBerat->bind_param("i", $product['id']);
        $stmtBerat->execute();
        $resultBerat = $stmtBerat->get_result();
        if ($resultBerat->num_rows === 1) {
            $rowBerat = $resultBerat->fetch_assoc();
            $berat_produk = $rowBerat['berat_produk'];
            $totalBerat += $berat_produk * $product['quantity'];
        }
        $stmtBerat->close();
    }

    // Total pembelian
    $totalPembelian = $totalBelanja + $ongkir;

    // Status dan lainnya
    $tanggalPembelian = date('Y-m-d');
    $status_pembayaran = 'Belum Dibayar';
    $metode_pengiriman = $ekspedisi;
    $status_pembelian = 'Belum dikirim';
    $resi_pengiriman = '';
    $tipe_transaksi = 'tidak langsung'; // Tambahkan tipe transaksi di sini
    $id_virtual = rand(); // Tambahkan titik koma di akhir pernyataan
    
    // Tambahkan variabel id_virtual ke dalam query
    $queryTransaksi = "INSERT INTO tb_transaksi (id_pelanggan, tanggal_transaksi, total_bayar, metode_pembayaran, status_pembayaran, alamat_pengiriman, metode_pengiriman, status_pembelian, resi_pengiriman, total_berat, provinsi, distrik, kode_pos, ekspedisi, paket, ongkir, estimasi, catatan, tipe_transaksi, id_virtual) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtTransaksi = $koneksi->prepare($queryTransaksi);
    $stmtTransaksi->bind_param(
        "isissssssdsisssssssi", 
        $user_id, 
        $tanggalPembelian, 
        $totalPembelian, 
        $metode_pembayaran, 
        $status_pembayaran, 
        $alamat_pengiriman, 
        $metode_pengiriman, 
        $status_pembelian, 
        $resi_pengiriman, 
        $totalBerat, 
        $provinsi, 
        $distrik, 
        $kodepos, 
        $ekspedisi, 
        $paket, 
        $ongkir, 
        $estimasi, 
        $catatan, 
        $tipe_transaksi,
        $id_virtual
    );
    $stmtTransaksi->execute();
    
    if ($stmtTransaksi->error) {
        echo "<script>alert('Error: " . $stmtTransaksi->error . "')</script>";
        exit();
    }
    
    $idTransaksi = $stmtTransaksi->insert_id;
    $stmtTransaksi->close();
    
    // Simpan data setiap produk dalam transaksi ke dalam tabel tb_pembelian_produk
    foreach ($_SESSION['cart'] as $product) {
        $queryProduk = "SELECT berat_produk FROM tb_sparepart WHERE id_produk = ?";
        $stmtProduk = $koneksi->prepare($queryProduk);
        $stmtProduk->bind_param("i", $product['id']);
        $stmtProduk->execute();
        $resultProduk = $stmtProduk->get_result();
        if ($resultProduk->num_rows === 1) {
            $rowProduk = $resultProduk->fetch_assoc();
            $berat_produk = $rowProduk['berat_produk'];
        } else {
            $berat_produk = 0; // atau penanganan
      }
      $stmtProduk->close();

      $queryPembelianProduk = "INSERT INTO tb_pembelian_produk (id_transaksi, id_produk, nama_produk, harga_produk, berat_produk, subberat, subharga, jumlah)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
      $subBerat = $berat_produk * $product['quantity'];
      $subHarga = $product['price'] * $product['quantity'];
      $stmtPembelianProduk = $koneksi->prepare($queryPembelianProduk);
      $stmtPembelianProduk->bind_param("iisddddi", $idTransaksi, $product['id'], $product['name'], $product['price'], $berat_produk, $subBerat, $subHarga, $product['quantity']);
      $stmtPembelianProduk->execute();
      if ($stmtPembelianProduk->error) {
          die("Execute failed: " . $stmtPembelianProduk->error);
      }
      $stmtPembelianProduk->close();

              // Update stok produk
              $queryUpdateStok = "UPDATE tb_sparepart SET jumlah_stok = jumlah_stok - ? WHERE id_produk = ?";
              $stmtUpdateStok = $koneksi->prepare($queryUpdateStok);
              $stmtUpdateStok->bind_param("ii", $product['quantity'], $product['id']);
              $stmtUpdateStok->execute();
              if ($stmtUpdateStok->error) {
                  echo "<script>alert('Error: " . $stmtUpdateStok->error . "')</script>";
                  exit();
              }
              $stmtUpdateStok->close();
          }
      
          // Kosongkan keranjang belanja
          unset($_SESSION['cart']);
      
          // Redirect ke halaman nota
          echo "<script>alert('Pembelian sukses');</script>";
          echo "<script>location='pesanan.php?id=$idTransaksi';</script>";
          header("location:./midtrans/examples/snap/checkout-process-simple-version.php");
          exit();
      }
      ?>
      
<!doctype html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
    <style>
       .small-input {
            width: 150px;
        }
      .center-text {
    text-align: center;
    }
    form select {
    width: calc(100% - 5px);
    padding: 3px;
    margin-top: 0px;
    margin-bottom: 0px;
    border: 1px solid #ccc;
    border-radius: 4px;
    }
    .product-weight, .total-weight {
            display: none;
        }
        .hidden-input {
            display: none;
        }
          <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'produk.php') {
            echo ".nav-item-produk a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'tentangkami.php') {
            echo ".nav-item-tentangkami a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php if ($current_page === 'masuk.php') : ?>
            .nav-link.dropdown-toggle {
                color: red !important;
            }
        <?php endif; ?>
        
          </style>


</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            <form class="d-flex">
                <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search">
                <button class="btn1" type="submit">Cari</button>
            </form> 
            <li class="nav-item dropdown no-arrow">
    <a  class="nav-link" id="userDropdown" role="button"
        aria-haspopup="true" aria-expanded="false">
        <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
        </svg>
    </a>
    <!-- Dropdown - User Information -->
    <div class="dropdown-menu1  shadow animated--grow-in"
        aria-labelledby="userDropdown">
        <a class="dropdown-item1" href="profil.php">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profil
        </a>
        <a class="dropdown-item1" href="pesanan.php">
            <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
            Pesanan
        </a>
        <div class="dropdown-divider1"></div>
        <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Keluar
        </a>
    </div>
</li>
        </div>
</nav>

</head>
<body>

<section class="container5">
    <div class="container-fluid px-4">
        <h3 class="mt-4">Halaman Checkout</h3>
    <form method="post" action="checkout.php">
<!-- Tabel checkout di halaman checkout.php -->
<table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Nomor</th>
                        <th class="product-name">Produk</th>
                        <th class="product-price">Harga</th>
                        <th class="product-quantity">Jumlah</th>
                        <th class="product-subtotal">Total</th>
                        <th class="product-weight">Berat (kg)</th> <!-- Tambahkan kolom berat -->
                    </tr>
                </thead>
                <!-- Isi tabel -->
                <tbody>
                    <?php
                    // Inisialisasi variabel nomor
                    $nomor = 1;
                    // Inisialisasi variabel total belanja
                    $totalBelanja = 0;
                    // Inisialisasi variabel total berat
                    $totalBerat = 0;
                    
                    // Perulangan untuk setiap produk dalam keranjang
                    foreach ($_SESSION['cart'] as $product) {
                        // Hitung subtotal
                        $subtotal = $product['price'] * $product['quantity'];
                    
                        // Tampilkan baris tabel untuk setiap produk
                        ?>
                        <tr>
                            <td><?php echo $nomor++; ?></td>
                            <td><?php echo $product['name']; ?></td>
                            <td>Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></td>
                            <td><?php echo $product['quantity']; ?></td>
                            <td>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></td>
                            <!-- Tampilkan kolom berat -->
                            <?php
                            $query = "SELECT berat_produk FROM tb_sparepart WHERE id_produk = ?";
                            $stmt = $koneksi->prepare($query);
                            $stmt->bind_param("i", $product['id']);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $row = $result->fetch_assoc();
                            $berat_produk = $row['berat_produk'];
                            $totalBerat += ($berat_produk * $product['quantity']); // Menambahkan berat produk pada total berat
                            ?>
                            <td class="product-weight"><?php echo $berat_produk; ?></td>
                        </tr>
                        <?php
                        
                        // Tambahkan subtotal ke total belanja
                        $totalBelanja += $subtotal;
                    }
                    ?>
                    <!-- Tampilkan total belanja -->
                    <tr>
                        <td colspan="4" class="text-right">Total Belanja:</td>
                        <td class="text-right">Rp <?php echo number_format($totalBelanja, 0, ',', '.'); ?></td>
                        <!-- Kolom total berat -->
                        <td class="total-weight"><?php echo $totalBerat; ?></td>
                    </tr>
                </tbody>
            </table>



        <!-- Informasi pengiriman -->
        <h5>Informasi Pengiriman</h5>

<!-- Form nama, nomor telepon, email -->
<div class="row mt-3">
    <div class="col-md-4">
        <label for="nama_pelanggan">Nama:</label>
        <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" value="<?php echo $nama_pelanggan; ?>" required>
    </div>
    <div class="col-md-4">
        <label for="no_telp">Nomor Telepon:</label>
        <input type="text" class="form-control" id="no_telp" name="no_telp" value="<?php echo $no_telp; ?>" required>
    </div>
    <div class="col-md-4">
        <label for="email">Email:</label>
        <input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>" required>
    </div>
</div>

<!-- Form alamat pengiriman dan catatan tambahan -->
<div class="row mt-3">
    <div class="col-md-6">
        <div class="form-group">
            <label for="alamat">Alamat Pengiriman:</label>
            <textarea class="form-control" id="alamat" name="alamat_pengiriman" rows="3" required><?php echo $alamat; ?></textarea>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="catatan">Catatan Tambahan (Opsional):</label>
            <textarea class="form-control" id="catatan" name="catatan" rows="3"></textarea>
        </div>
    </div>
</div>

<!-- Form select untuk provinsi, kabupaten/kota, ekspedisi, dan paket -->
<div class="row mt-3">
    <div class="col-md-3">
        <div class="form-group">
            <label>Provinsi:</label>
            <div class="input-group">
                <select name="nama_provinsi" class="form-control" required></select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-chevron-down" style="line-height: 25px;"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label>Kabupaten/Kota:</label>
            <div class="input-group">
                <select name="nama_distrik" class="form-control" required>
                    <option value="">- Pilih Kabupaten/Kota -</option>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-chevron-down" style="line-height: 25px;"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label>Ekspedisi:</label>
            <div class="input-group">
                <select name="nama_ekspedisi" class="form-control" required>
                    <option value="">- Pilih Ekspedisi -</option>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-chevron-down" style="line-height: 25px;"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label>Paket:</label>
            <div class="input-group">
                <select name="nama_paket" class="form-control" required>
                    <option value="">- Pilih Paket -</option>
                </select>
                <div class="input-group-append">
                    <span class="input-group-text"><i class="fas fa-chevron-down" style="line-height: 25px;"></i></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="provinsi" placeholder="Provinsi" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="distrik" placeholder="Distrik" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="tipe" placeholder="Tipe" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="kodepos" placeholder="Kode Pos" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="ekspedisi" placeholder="Ekspedisi" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="paket" placeholder="Paket" required readonly>
        </div>
    </div>
</div>
<div class="row mt-3">
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="ongkir" placeholder="Ongkir" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control" name="estimasi" placeholder="Estimasi" required readonly>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group mb-3">
            <input type="text" class="form-control hidden-input" name="total_berat" value="<?php echo $totalBerat; ?>" required readonly>
        </div>
    </div>
</div>


<button type="submit" class="btn btn-danger mt-3" name="checkout">Checkout</button>
</form>
    </div>
</section>

<footer id="footer" class="overflow-hidden padding-large">
      <div class="container-fluid">
        <div class="row">
          <div class="row d-flex flex-wrap justify-content-between">
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Quick Links</h5>
                <ul class="menu-list list-unstyled text-uppercase">
                  <li class="menu-item pb-2">
                    <a href="home.php">Home</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="tentangkami.php">Tentang Kami</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="produk.php">Produk</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="profil.php">Akun</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Metode Pembayaran</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <img src="img/bankbri.png" alt="Pembayaran" width="80">
                  </ul>
                  <h5 class="widget-title pb-2">Metode Pengiriman</h5>
                  <ul class="list-unstyled">
                    <img src="img/jnt.jpg" alt="Pengiriman" width="80">
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Sosial Media</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <li class="pb-2">
                      <a href="#">Facebook</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Twitter</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Instagram</a>
                    </li>
                    <li>
                      <a href="#">Youtube</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="footer-menu contact-item">
                <h5 class="widget-title text-uppercase pb-2">Hubungi Kami</h5>
                <p><a>+6282212345678</a></p>
                <h5 class="widget-title text-uppercase pb-2">Alamat</h5>
                <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
                <a href="https://www.google.com/maps/dir//Bedaro+Rampak,+Kec.+Tebo+Tengah,+Kabupaten+Tebo,+Jambi+37573/@-1.4626859,102.3438694,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e2ebf920b1d11e9:0xf9a5555e1f34bbda!2m2!1d102.4262714!2d-1.4626874?entry=ttu">
                <img src="img/maps.png" alt="Alamat Kami" width="150">
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer> 
    
      
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
document.getElementById('ongkir').addEventListener('input', function() {
  var ongkir = parseInt(this.value);
  var totalBelanja = <?php echo $totalBelanja;?>;
  var totalKeseluruhan = totalBelanja + ongkir;
  document.getElementById('total-keseluruhan').value = 'Rp ' + totalKeseluruhan.toLocaleString('id-ID');
});
</script>


<script>
    $(document).ready(function(){
      $.ajax({
        type: 'post',
        url: 'dataprovinsi.php',
        success: function(hasil_provinsi){
          $("select[name=nama_provinsi]").html(hasil_provinsi);
        }
      });

      $("select[name=nama_provinsi]").on("change", function(){
        // Ambil id_provinsi ynag dipilih (dari atribut pribadi)
        var id_provinsi_terpilih = $("option:selected", this).attr("id_provinsi");
        $.ajax({
          type: 'post',
          url: 'datadistrik.php',
          data: 'id_provinsi='+id_provinsi_terpilih,
          success:function(hasil_distrik){
            $("select[name=nama_distrik]").html(hasil_distrik);
          }
        })
      });

      $.ajax({
        type: 'post',
        url: 'jasaekspedisi.php',
        success: function(hasil_ekspedisi){
          $("select[name=nama_ekspedisi]").html(hasil_ekspedisi);
        }
      });

      $("select[name=nama_ekspedisi]").on("change", function(){
        // Mendapatkan data ongkos kirim

        // Mendapatkan ekspedisi yang dipilih
        var ekspedisi_terpilih = $("select[name=nama_ekspedisi]").val();
        // Mendapatkan id_distrik yang dipilih
        var distrik_terpilih = $("option:selected", "select[name=nama_distrik]").attr("id_distrik");
        // Mendapatkan toatal berat dari inputan
        $total_berat = $("input[name=total_berat]").val();
        $.ajax({
          type: 'post',
          url: 'datapaket.php',
          data: 'ekspedisi='+ekspedisi_terpilih+'&distrik='+distrik_terpilih+'&berat='+$total_berat,
          success: function(hasil_paket){
            // console.log(hasil_paket);
            $("select[name=nama_paket]").html(hasil_paket);

            // Meletakkan nama ekspedisi terpilih di input ekspedisi
            $("input[name=ekspedisi]").val(ekspedisi_terpilih);
          }
        })
      });

      $("select[name=nama_distrik]").on("change", function(){
        var prov = $("option:selected", this).attr('nama_provinsi');
        var dist = $("option:selected", this).attr('nama_distrik');
        var tipe = $("option:selected", this).attr('tipe_distrik');
        var kodepos = $("option:selected", this).attr('kodepos');
        
        $("input[name=provinsi]").val(prov);
        $("input[name=distrik]").val(dist);
        $("input[name=tipe]").val(tipe);
        $("input[name=kodepos]").val(kodepos);
      });

      $("select[name=nama_paket]").on("change", function(){
        var paket = $("option:selected", this).attr("paket");
        var ongkir = $("option:selected", this).attr("ongkir");
        var etd = $("option:selected", this).attr("etd");

        $("input[name=paket]").val(paket);
        $("input[name=ongkir]").val(ongkir);
        $("input[name=estimasi]").val(etd);
      })
    });
  </script>

</body>
</html>

