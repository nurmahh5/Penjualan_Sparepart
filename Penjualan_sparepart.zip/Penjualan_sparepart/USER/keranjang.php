<?php
session_start();
require 'koneksi.php'; // Pastikan Anda terhubung ke database

// Fungsi untuk menambahkan produk ke keranjang
function addToCart($product_id) {
    global $koneksi;
    $query = "SELECT * FROM tb_sparepart WHERE id_produk = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    if (!$product) {
        return false; // Produk tidak ditemukan
    }

    $product_name = $product['nama_produk'];
    $product_price = $product['harga_produk'];

    // Periksa apakah keranjang sudah ada dalam sesi
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Periksa apakah produk sudah ada di keranjang
    if (isset($_SESSION['cart'][$product_id])) {
        // Jika sudah ada, tambahkan jumlah produk
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    } else {
        // Jika belum ada, tambahkan produk baru ke keranjang
        $_SESSION['cart'][$product_id] = [
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'quantity' => 1
        ];
    }
}

// Fungsi untuk menghapus produk dari keranjang
function removeFromCart($product_id) {
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

// Contoh penggunaan
if (isset($_GET['action'])) {
    $action = $_GET['action'];

    if ($action == 'add' && isset($_GET['product_id'])) {
        $product_id = $_GET['product_id'];
        addToCart($product_id);
        header("Location: keranjang.php");
        exit();
    } elseif ($action == 'remove' && isset($_GET['product_id'])) {
        $product_id = $_GET['product_id'];
        removeFromCart($product_id);
        header("Location: keranjang.php");
        exit();
    }
}
function displayCart() {
    global $koneksi;

    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<tr><td colspan='6'>Keranjang Anda kosong.</td></tr>";
        return;
    }

    foreach ($_SESSION['cart'] as $product) {
        $query = "SELECT gambar_produk FROM tb_sparepart WHERE id_produk = ?";
        $stmt = $koneksi->prepare($query);
        $stmt->bind_param("i", $product['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $gambar_produk = $row['gambar_produk'];

        echo "<tr data-id='{$product['id']}'>";
        echo "<td class='product-remove'><a href='keranjang.php?action=remove&product_id={$product['id']}' class='remove'>×</a></td>";
        echo "<td class='product-thumbnail'><img src='{$gambar_produk}' alt='{$product['name']}' class='centered-image' width='35' height='35' /></td>";
        echo "<td class='product-name'>{$product['name']}</td>";
        echo "<td class='product-price'>Rp " . number_format($product['price'], 0, ',', '.') . "</td>";
        echo "<td class='product-quantity'><input type='number' id='quantity_{$product['id']}' value='{$product['quantity']}' min='1' onchange='updateTotal({$product['id']}, {$product['price']})' /></td>";
        echo "<td class='product-subtotal' id='subtotal_{$product['id']}'>Rp " . number_format($product['price'] * $product['quantity'], 0, ',', '.') . "</td>";
        echo "</tr>";
    }
}

?>


<!doctype html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
    <style>
        .product-thumbnail {
    text-align: center; /* Centers the image horizontally */
}

.product-thumbnail .centered-image {
    display: block; /* Ensures the image is treated as a block element */
    margin: 0 auto; /* Centers the image within the parent element */
}

    <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'produk.php') {
            echo ".nav-item-produk a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'tentangkami.php') {
            echo ".nav-item-tentangkami a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php if ($current_page === 'masuk.php') : ?>
            .nav-link.dropdown-toggle {
                color: red !important;
            }
        <?php endif; ?>
        
          </style>


</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>
 
            <li class="nav-item dropdown no-arrow">
    <a  class="nav-link" id="userDropdown" role="button"
        aria-haspopup="true" aria-expanded="false">
        <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
        </svg>
    </a>
    <!-- Dropdown - User Information -->
    <div class="dropdown-menu1  shadow animated--grow-in"
        aria-labelledby="userDropdown">
        <a class="dropdown-item1" href="profil.php">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profil
        </a>
        <a class="dropdown-item1" href="pesanan.php">
            <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
            Pesanan
        </a>
        <div class="dropdown-divider1"></div>
        <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Keluar
        </a>
    </div>
</li>
        </div>
</nav>

<section class="container3">
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="home.php">Home</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="profil.php">Profil</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="produk.php">Produk</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="tentangkami.php">Tentang Kami</a>
                    
                </div>
            </div>
        
                <div class="container-fluid">
                    <h3 class="mt-4">Keranjang Anda</h3>
                    <table class="table table-bordered">
    <thead class="table-dark">
        <tr>
            <th class="product-remove">&nbsp;</th>
            <th class="product-thumbnail">&nbsp;</th>
            <th class="product-name">Produk</th>
            <th class="product-price">Harga</th>
            <th class="product-quantity">Jumlah</th>
            <th class="product-subtotal">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php displayCart(); ?>
    </tbody>
</table>
<div class="table-container">
    <h4>Total Keranjang Belanja</h4>
    <table class="tableco">
        <tbody>
            <tr>
                <td>Subtotal:</td>
                <td id="subtotal_all">Rp </td>
            </tr>
            <tr>
                <td>Total Harga:</td>
                <td id="total_harga">Rp </td>
            </tr>
        </tbody>
    </table>
    <div class="button-wrapper">
        <button class="button-shopping" onclick="location.href='produk.php'">Lanjut Berbelanja</button>
        <button class="button-checkout" onclick="location.href='checkout.php'">Lanjut ke Checkout</button>
    </div>
</div>

</section>

<footer id="footer" class="overflow-hidden padding-large">
      <div class="container-fluid">
        <div class="row">
          <div class="row d-flex flex-wrap justify-content-between">
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Quick Links</h5>
                <ul class="menu-list list-unstyled text-uppercase">
                  <li class="menu-item pb-2">
                    <a href="home.php">Home</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="tentangkami.php">Tentang Kami</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="produk.php">Produk</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="profil.php">Akun</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Metode Pembayaran</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <img src="img/bankbri.png" alt="Pembayaran" width="80">
                  </ul>
                  <h5 class="widget-title pb-2">Metode Pengiriman</h5>
                  <ul class="list-unstyled">
                    <img src="img/jnt.jpg" alt="Pengiriman" width="80">
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Sosial Media</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <li class="pb-2">
                      <a href="#">Facebook</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Twitter</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Instagram</a>
                    </li>
                    <li>
                      <a href="#">Youtube</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="footer-menu contact-item">
                <h5 class="widget-title text-uppercase pb-2">Hubungi Kami</h5>
                <p><a>+6282212345678</a></p>
                <h5 class="widget-title text-uppercase pb-2">Alamat</h5>
                <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
                <a href="https://www.google.com/maps/dir//Bedaro+Rampak,+Kec.+Tebo+Tengah,+Kabupaten+Tebo,+Jambi+37573/@-1.4626859,102.3438694,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e2ebf920b1d11e9:0xf9a5555e1f34bbda!2m2!1d102.4262714!2d-1.4626874?entry=ttu">
                <img src="img/maps.png" alt="Alamat Kami" width="150">
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer> 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>


<script>
        function updateTotal(idProduk, hargaProduk) {
    var quantity = parseInt(document.getElementById('quantity_' + idProduk).value);
    var subtotal = quantity * hargaProduk;
    document.getElementById('subtotal_' + idProduk).innerHTML = '<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">Rp</span>' + subtotal.toLocaleString('id-ID') + '</bdi></span>';

    // Update total harga semua item
    updateTotalHarga();

    // Kirim permintaan AJAX untuk memperbarui sesi
    $.ajax({
        url: 'update_cart.php',
        type: 'POST',
        data: {
            product_id: idProduk,
            quantity: quantity
        },
        success: function(response) {
            console.log(response); // Debug response jika diperlukan
        }
    });
}

function updateTotalHarga() {
    var totalHarga = 0;
    var subtotals = document.querySelectorAll('.product-subtotal');
    subtotals.forEach(function(subtotal) {
        var hargaStr = subtotal.innerText.replace(/[^\d]/g, ''); // Remove non-numeric characters
        if (!isNaN(hargaStr) && hargaStr.length > 0) {
            totalHarga += parseInt(hargaStr);
        }
    });

    document.getElementById('subtotal_all').innerText = 'Rp ' + totalHarga.toLocaleString('id-ID');
    document.getElementById('total_harga').innerText = 'Rp ' + totalHarga.toLocaleString('id-ID');
}

// Panggil updateTotalHarga() sekali untuk menginisialisasi total harga
document.addEventListener('DOMContentLoaded', function() {
    updateTotalHarga();
});

    </script>
</body>
</html>


