<?php
session_start();
require 'koneksi.php';

// Ambil ID pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Ambil data pengguna dari database
$stmt = $koneksi->prepare("SELECT * FROM tabel_pelanggan WHERE id_pelanggan = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $nama_pelanggan = $row['nama_pelanggan'];
    $email = $row['email'];
    $no_telp = $row['no_telp'];
    $alamat = $row['alamat'];
    // Password tidak perlu dimasukkan ke dalam formulir
} else {
    echo "Data pengguna tidak ditemukan.";
}
$stmt->close();

// Memproses permintaan pengeditan profil
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir
    $nama_pelanggan_baru = $_POST['nama_pelanggan'];
    $email_baru = $_POST['email'];
    $no_telp_baru = $_POST['no_telp'];
    $alamat_baru = $_POST['alamat'];
    $password_baru = $_POST['password']; // Tambahkan input untuk password baru
    // Ubah data pengguna dalam database
    $stmt = $koneksi->prepare("UPDATE tabel_pelanggan SET nama_pelanggan = ?, email = ?, no_telp = ?, alamat = ?, password = ? WHERE id_pelanggan = ?");
    $stmt->bind_param("sssssi", $nama_pelanggan_baru, $email_baru, $no_telp_baru, $alamat_baru, $password_baru, $user_id); // Masukkan password baru ke dalam pernyataan SQL
    if ($stmt->execute()) {
        // Redirect user kembali ke halaman profil setelah pembaruan berhasil
        header("Location: profil.php");
        exit();
    } else {
        echo "Gagal menyimpan perubahan profil.";
    }
    $stmt->close();
}
?>
