<?php
session_start();

if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Periksa apakah produk ada di keranjang
    if (isset($_SESSION['cart'][$product_id])) {
        // Perbarui jumlah produk di sesi
        $_SESSION['cart'][$product_id]['quantity'] = $quantity;
        echo "Jumlah produk diperbarui.";
    } else {
        echo "Produk tidak ditemukan di keranjang.";
    }
} else {
    echo "Data tidak valid.";
}
?>
