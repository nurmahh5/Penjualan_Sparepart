<?php
// Pastikan file koneksi.php sudah menyertakan koneksi ke database
require 'koneksi.php';
?>


<!DOCTYPE html>
<html lang="ar" dir="ltr">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
    <style>

        /* Tambahkan warna merah pada tulisan "Akun" saat berada di halaman 'masuk.php' */
        <?php if ($current_page === 'daftar.php') : ?>
            .nav-link.dropdown-toggle {
                color: red !important;
            }
        <?php endif; ?>
    </style>
</head>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div> 
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>

            
        </div>
</nav>
<?php
    if (isset($_GET['error'])) {
        echo '<p style="color:red;">' . $_GET['error'] . '</p>';
    }
    ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card">
    <div class="card-body">
        <h3 class="card-title text-center">Buat Akun</h3>
        <div class="row">
            <form action="prosesdaftar.php" method="post">
                    <div>
                        <label for="nama_pelanggan" class="form-label">Nama</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-user-circle"></i>
                            </span>
                            <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" placeholder="Masukkan Nama">
                        </div>
                    </div>
                    <div>
                        <label for="email" class="form-label">Alamat Email</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email"  required>
                        </div>
                    </div>
                    <div >
                        <label for="no_telp" class="form-label">Nomor Telepon</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="fas fa-phone"></i>
                            </span>
                            <input type="text" class="form-control" id="no_telp" name="no_telp" placeholder="Masukkan No Telp"  required>
                        </div>
                    </div>
                <div>
                <label for="inputAlamat" class="form-label">Alamat</label>
                <div class="input-group">
                <span class="input-group-text">
                                <i class="fas fa-map-marker-alt"></i>
                            </span>
                <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Masukkan Alamat" required>
                </div>
             </div>
                <div>
                    <label for="password" class="form-label">Kata Sandi</label>
                    <div class="input-group">
                        <span class="input-group-text">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Buat Kata Sandi"  required>
                        <button class="btn btn-dark" type="button" id="togglePassword">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
        <div class="text-center">
            <button type="submit" class="btn3 mt-3">Daftar</button>
        </div>
    </div>
</div>
</form>
            </div>
        </div>
    </div>
</div>
<script>
    const togglePassword = document.getElementById('togglePassword');
    const passwordField = document.getElementById('password');

    togglePassword.addEventListener('click', function() {
        const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordField.setAttribute('type', type);
        this.classList.toggle('bi-eye');
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</body>
</html>
