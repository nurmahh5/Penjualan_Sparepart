<?php
session_start();
// Pastikan file koneksi.php sudah menyertakan koneksi ke database
require 'koneksi.php';

// Periksa apakah pengguna sudah masuk, jika belum, alihkan ke halaman masuk
if (!isset($_SESSION['user_id'])) {
    header("Location: masuk.php");
    exit();
}

// Ambil ID pengguna dari sesi
$user_id = $_SESSION['user_id'];

// Gunakan prepared statement untuk menghindari serangan SQL injection
$stmt = $koneksi->prepare("SELECT * FROM tabel_pelanggan WHERE id_pelanggan = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Periksa apakah query berhasil dieksekusi
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $nama_pelanggan = $row['nama_pelanggan'];
    $email = $row['email'];
    $no_telp = $row['no_telp'];
    $alamat = $row['alamat'];
    $password = $row['password'];
} else {
    // Jika data tidak ditemukan, lakukan sesuatu (misalnya, tampilkan pesan kesalahan)
    echo "Data pengguna tidak ditemukan.";
}
$stmt->close();
?>


<!doctype html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 

    <title>TEGUH RAYA MOTOR</title>
    <style>
      
<?php 
$koneksi = mysqli_connect('localhost','root','','penjualan_sparepart');
?>
    <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'produk.php') {
            echo ".nav-item-produk a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'tentangkami.php') {
            echo ".nav-item-tentangkami a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php if ($current_page === 'masuk.php') : ?>
            .nav-link.dropdown-toggle {
                color: red !important;
            }
        <?php endif; ?>
        
          </style>

</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>
            <li class="nav-item dropdown no-arrow">
    <a  class="nav-link" id="userDropdown" role="button"
        aria-haspopup="true" aria-expanded="false">
        <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
        </svg>
    </a>
    <!-- Dropdown - User Information -->
    <div class="dropdown-menu1  shadow animated--grow-in"
        aria-labelledby="userDropdown">
        <a class="dropdown-item1" href="profil.php">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profil
        </a>
        <a class="dropdown-item1" href="pesanan.php">
            <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
            Pesanan
        </a>
        <div class="dropdown-divider1"></div>
        <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Keluar
        </a>
    </div>
</li>
        </div>
</nav>


<section class="container3">
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="home.php">Home</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="profil.php">Profil</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="pesanan.php">Pesanan</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="produk.php">Produk</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="tentangkami.php">Tentang Kami</a>
                    
                </div>
            </div>
        
                <div class="container-fluid">
                    <h3 class="mt-4">Profil Anda</h3>
                    <p> Ini profil akun anda. Anda bisa mengubahnya.</p>
                    <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                        <th>Nama Pengguna</th>
                        <th>Email</th>
                        <th>No. Telp</th>
                        <th>Alamat Pengiriman</th>
                        <th>Password</th>
                        </tr>
                    </thead>
                    <tbody>
            <tr>
                <td><?php echo $nama_pelanggan; ?></td>
                <td><?php echo $email; ?></td>
                <td><?php echo $no_telp; ?></td>
                <td><?php echo $alamat; ?></td>
                <td>
        <span id="passwordHidden"><?php echo str_repeat("*", strlen($password)); ?></span> <!-- Menampilkan password sebagai bintang -->
    </td>           
   </tr>
        </tbody>
                    </table>
                    <button class="btn btn-danger"  data-bs-toggle="modal" data-bs-target="#editProfileModal">Edit Profil</button>
                </div>
        </div>

        <!-- Modal for editing profile -->
<div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProfileModalLabel">Edit Profil</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form for editing profile -->
                <form method="post" action="editprofil.php">
                    <!-- Form fields for editing profile details -->
                    <div class="mb-3">
                        <label for="editNama" class="col-form-label">Nama</label>
                        <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" value="<?php echo $nama_pelanggan; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="editEmail" class="col-form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="editPhone" class="col-form-label">No. Telp</label>
                        <input type="text" class="form-control" id="no_telp" name="no_telp" value="<?php echo $no_telp; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="editAddress" class="col-form-label">Alamat</label>
                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo $alamat; ?>">
                    </div>                   
              <div class="mb-3">
              <label for="editPassword" class="col-form-label">Ubah Kata Sandi</label>
              <div class="input-group">
                  <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan kata sandi baru">
                  <button class="btn btn-outline-dark" type="button" id="togglePasswordVisibility">
                      <i class="bi bi-eye"></i>
                  </button>
              </div>
          </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="submit" class="btn btn-danger">Simpan Perubahan</button>
            </div>
            </form>
        </div>
    </div>
</div>

</section>
<footer id="footer" class="overflow-hidden padding-large">
      <div class="container-fluid">
        <div class="row">
          <div class="row d-flex flex-wrap justify-content-between">
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Quick Links</h5>
                <ul class="menu-list list-unstyled text-uppercase">
                  <li class="menu-item pb-2">
                    <a href="home.php">Home</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="tentangkami.php">Tentang Kami</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="produk.php">Produk</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="profil.php">Akun</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Metode Pembayaran</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <img src="img/bankbri.png" alt="Pembayaran" width="80">
                  </ul>
                  <h5 class="widget-title pb-2">Metode Pengiriman</h5>
                  <ul class="list-unstyled">
                    <img src="img/jnt.jpg" alt="Pengiriman" width="80">
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Sosial Media</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <li class="pb-2">
                      <a href="#">Facebook</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Twitter</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Instagram</a>
                    </li>
                    <li>
                      <a href="#">Youtube</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="footer-menu contact-item">
                <h5 class="widget-title text-uppercase pb-2">Hubungi Kami</h5>
                <p><a>+6282212345678</a></p>
                <h5 class="widget-title text-uppercase pb-2">Alamat</h5>
                <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
                <a href="https://www.google.com/maps/dir//Bedaro+Rampak,+Kec.+Tebo+Tengah,+Kabupaten+Tebo,+Jambi+37573/@-1.4626859,102.3438694,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e2ebf920b1d11e9:0xf9a5555e1f34bbda!2m2!1d102.4262714!2d-1.4626874?entry=ttu">
                <img src="img/maps.png" alt="Alamat Kami" width="150">
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer> 

    <script>
    $(document).ready(function() {
        // Mengisi nilai bidang input dalam modal dengan data profil pengguna
        $('#editProfileModal').on('show.bs.modal', function(event) {
            var modal = $(this);
            modal.find('#nama_pelanggan').val('<?php echo $nama_pelanggan; ?>');
            modal.find('#email').val('<?php echo $email; ?>');
            modal.find('#no_telp').val('<?php echo $no_telp; ?>');
            modal.find('#alamat').val('<?php echo $alamat; ?>');
            modal.find('#password').val('<?php echo $password; ?>');
            // Tidak merekomendasikan mengisi bidang kata sandi dalam modal untuk alasan keamanan
        });
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const passwordInput = document.getElementById("password");
        const togglePasswordVisibilityButton = document.getElementById("togglePasswordVisibility");
        
        // Tambahkan event listener untuk klik pada tombol toggle visibilitas
        togglePasswordVisibilityButton.addEventListener("click", function() {
            // Toggle visibilitas input password
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                togglePasswordVisibilityButton.innerHTML = '<i class="bi bi-eye-slash"></i>';
            } else {
                passwordInput.type = "password";
                togglePasswordVisibilityButton.innerHTML = '<i class="bi bi-eye"></i>';
            }
        });
    });
</script>

  

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>

        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>
