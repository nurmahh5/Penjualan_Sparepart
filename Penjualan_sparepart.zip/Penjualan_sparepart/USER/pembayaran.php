<?php
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

// Mulai sesi
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum, arahkan ke halaman login
    header("Location: masuk.php");
    exit();
}

// Ambil ID pengguna dari sesi
$id_pelanggan = $_SESSION['user_id'];

// Ambil data transaksi berdasarkan ID pengguna
$query = "SELECT * FROM tb_transaksi WHERE id_pelanggan = '$id_pelanggan'";
$result = mysqli_query($koneksi, $query);

if ($result === false) {
    // Jika query gagal, tampilkan pesan error
    echo "Error: " . mysqli_error($koneksi);
    exit();
}
?>

<!doctype html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
    <style>
    <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        if (basename($_SERVER['PHP_SELF']) == 'produk.php') {
            echo ".nav-item-produk a.nav-link { color: red !important; }";
        }
        if (basename($_SERVER['PHP_SELF']) == 'tentangkami.php') {
            echo ".nav-item-tentangkami a.nav-link { color: red !important; }";
        }
    ?>
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item nav-item-home">
                    <a class="nav-link active" aria-current="page" href="home.php">Home</a>
                </li>
                <li class="nav-item nav-item-tentangkami">
                    <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
                </li>
                <li class="nav-item nav-item-produk">
                    <a class="nav-link" href="produk.php">PRODUK</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                        <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
                    </ul>
                </li>
            </ul>
            <button class="btn0" onclick="location.href='keranjang.php'">
                <div class="d-flex align-items-center">
                    <i class="bi bi-cart-fill px-1"></i>
                </div>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link" id="userDropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
                        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
                        <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
                    </svg>
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu1  shadow animated--grow-in" aria-labelledby="userDropdown">
                    <a class="dropdown-item1" href="profil.php">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>Profil
                    </a>
                    <a class="dropdown-item1" href="pesanan.php">
                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>Pesanan
                    </a>
                    <div class="dropdown-divider1"></div>
                    <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>Keluar
                    </a>
                </div>
            </li>
        </div>
    </div>
</nav>

<section class="container3">
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="border-end bg-white" id="sidebar-wrapper">
            <div class="list-group list-group-flush">
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="home.php">Home</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="profil.php">Profil</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="pesanan.php">Pesanan</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="produk.php">Produk</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="tentangkami.php">Tentang Kami</a>
            </div>
        </div>
        <!-- Page content-->
        <div class="container-fluid">
            <h3 class="mt-4">Total Bayar Anda</h3>
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>No Pesanan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Metode Pembayaran</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id_transaksi'] . "</td>";
                        echo "<td>" . $row['tanggal_transaksi'] . "</td>";
                        echo "<td>Rp. " . number_format($row['total_bayar'], 0, ',', '.') . "</td>";
                        echo "<td>" . $row['metode_pembayaran'] . "</td>";
                        echo "<td>
                        <a href='pembayaran.php?id=" . $row['id_virtual'] . "' class='btn btn-danger'>Bayar Sekarang</a>
                        </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
                </tbody>
            </table>
        </div>
    </div>
</section>

<footer id="footer" class="overflow-hidden padding-large">
    <div class="container-fluid">
        <div class="row">
            <div class="row d-flex flex-wrap justify-content-between">
                <div class="col-lg-2 col-sm-6 pb-3">
                    <div class="footer-menu text-uppercase">
                        <h5 class="widget-title pb-2">Quick Links</h5>
                        <ul class="menu-list list-unstyled text-uppercase">
                            <li class="menu-item pb-2"><a href="home.php">Home</a></li>
                            <li class="menu-item pb-2"><a href="tentangkami.php">Tentang Kami</a></li>
                            <li class="menu-item pb-2"><a href="produk.php">Produk</a></li>
                            <li class="menu-item pb-2"><a href="profil.php">Akun</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-sm-6 pb-3">
                    <div class="footer-menu text-uppercase">
                        <h5 class="widget-title pb-2">Metode Pembayaran</h5>
                        <div class="social-links">
                            <ul class="list-unstyled">
                                <img src="img/bankbri.png" alt="Pembayaran" width="80">
                            </ul>
                            <h5 class="widget-title pb-2">Metode Pengiriman</h5>
                            <ul class="list-unstyled">
                                <img src="img/jnt.jpg" alt="Pengiriman" width="80">
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-sm-6 pb-3">
                    <div class="footer-menu text-uppercase">
                        <h5 class="widget-title pb-2">Sosial Media</h5>
                        <div class="social-links">
                            <ul class="list-unstyled">
                                <li class="pb-2"><a href="#">Facebook</a></li>
                                <li class="pb-2"><a href="#">Twitter</a></li>
                                <li class="pb-2"><a href="#">Instagram</a></li>
                                <li><a href="#">Youtube</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="footer-menu contact-item">
                        <h5 class="widget-title text-uppercase pb-2">Hubungi Kami</h5>
                        <p><a>+6282212345678</a></p>
                        <h5 class="widget-title text-uppercase pb-2">Alamat</h5>
                        <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
                        <a href="https://www.google.com/maps/dir//Bedaro+Rampak,+Kec.+Tebo+Tengah,+Kabupaten+Tebo,+Jambi+37573/@-1.4626859,102.3438694,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e2ebf920b1d11e9:0xf9a5555e1f34bbda!2m2!1d102.4262714!2d-1.4626874?entry=ttu">
                            <img src="img/maps.png" alt="Alamat Kami" width="150">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer> 

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>
