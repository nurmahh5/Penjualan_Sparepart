<?php
// Pastikan file koneksi.php sudah menyertakan koneksi ke database
require 'koneksi.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        echo "Email dan password harus diisi.";
        exit();
    }

    // Perbarui kueri SQL untuk mencocokkan dengan struktur tabel_pelanggan
    $sql = "SELECT id_pelanggan, email, password FROM tabel_pelanggan WHERE email = ?";
    if ($stmt = $koneksi->prepare($sql)) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id_pelanggan, $db_email, $db_password);
            $stmt->fetch();

            if ($password === $db_password) {
                $_SESSION['user_id'] = $id_pelanggan; // Simpan ID pelanggan
                $_SESSION['email'] = $db_email; // Simpan email
                $_SESSION['success_message'] = "Login berhasil!"; // Tambahkan pesan sukses
                header("Location: home.php");
                exit();
            } else {
                $error_message = "Password salah.";
            }
        } else {
            $error_message = "Pengguna tidak ditemukan.";
        }
        $stmt->close();
    } else {
        $error_message = "Terjadi kesalahan pada query: " . $koneksi->error;
    }

    $koneksi->close();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item nav-item-home">
                        <a class="nav-link active" aria-current="page" href="home.php">Home</a>
                    </li>
                    <li class="nav-item nav-item-tentangkami">
                        <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
                    </li>
                    <li class="nav-item nav-item-produk">
                        <a class="nav-link" href="produk.php">PRODUK</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                            <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
                <div class="d-flex align-items-center">
                    <i class="bi bi-cart-fill px-1"></i>
                </div>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-center">Masuk Akun</h3>
                        <form action="masuk.php" method="post">
                            <div class="mb-3">
                                <label for="emailpengguna" class="form-label">Email Pengguna</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email Pengguna">
                                </div>
                            </div>
                            <div>
                                <label for="password" class="form-label">Kata Sandi</label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan Kata Sandi">
                                    <button class="btn btn-dark" type="button" id="togglePassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn3 mt-3">Masuk</button>
                            </div>
                        </form>
                        <div class="text-center mt-3">
                            <p>Belum punya akun? <a href="daftar.php">Daftar sekarang</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast untuk pesan kesalahan -->
    <?php if (!empty($error_message)) : ?>
        <div class="toast align-items-center text-white bg-danger border-0" role="alert" aria-live="assertive" aria-atomic="true" style="position: fixed; top: 20px; right: 20px; z-index: 1">
            <div class="d-flex">
                <div class="toast-body">
                    <?php echo $error_message; ?>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <!-- Toast untuk pesan berhasil -->
    <?php if (!empty($success_message)) : ?>
        <div class="toast align-items-center text-white bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true" style="position: fixed; top: 20px; right: 20px; z-index: 1">
            <div class="d-flex">
                <div class="toast-body">
                    <?php echo $success_message; ?>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    <?php endif; ?>

    <script>
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('password');

        togglePassword.addEventListener('click', function() {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            this.classList.toggle('bi-eye');
        });

        // Menampilkan toast jika ada
        document.addEventListener('DOMContentLoaded', function () {
            var toastElList = [].slice.call(document.querySelectorAll('.toast'))
            var toastList = toastElList.map(function (toastEl) {
                return new bootstrap.Toast(toastEl, { delay: 3000 });
            });
            toastList.forEach(toast => toast.show());
        });
    </script>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>
