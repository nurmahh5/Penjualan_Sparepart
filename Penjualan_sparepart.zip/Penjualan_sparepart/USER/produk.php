<?php
// Memulai atau melanjutkan sesi
session_start();

// Fungsi untuk menambahkan produk ke dalam sesi keranjang
function tambahkanKeKeranjang($id_produk) {
    // Jika sesi keranjang belum ada, buat sesi baru
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = array();
    }

    // Tambahkan produk ke dalam sesi keranjang
    $_SESSION['keranjang'][] = $id_produk;
}

// Jika tombol "Tambah ke Keranjang" ditekan
if (isset($_POST['add_to_cart'])) {
    // Periksa apakah ada ID produk yang dikirimkan
    if (isset($_POST['product_id'])) {
        // Tambahkan produk ke dalam sesi keranjang
        tambahkanKeKeranjang($_POST['product_id']);
    }
}

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

// Periksa koneksi database
if (mysqli_connect_errno()) {
    echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
    exit();
}

// Query awal untuk menampilkan semua produk
$query = "SELECT * FROM tb_sparepart";

// Jika ada parameter kategori di URL dan nilainya tidak kosong, filter berdasarkan kategori tersebut
if (isset($_GET['kategori']) && $_GET['kategori'] !== '' && $_GET['kategori'] !== 'semua') {
    $kategori = $_GET['kategori'];
    $query .= " WHERE kategori_produk = '$kategori'";
}

$result = mysqli_query($koneksi, $query);
?>


<!doctype html>
<html lang="ar" dir="ltr">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

    <title>TEGUH RAYA MOTOR</title>
    <style>
        
    <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'produk.php') {
            echo ".nav-item-produk a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'tentangkami.php') {
            echo ".nav-item-tentangkami a.nav-link { color: red !important; }";
        }
        ?>
        <?php
        // Jika berada di halaman produk.php, tambahkan warna merah pada navigasi
        if (basename($_SERVER['PHP_SELF']) == 'home.php') {
            echo ".nav-item-home a.nav-link { color: red !important; }";
        }
        ?>
        <?php if ($current_page === 'masuk.php') : ?>
            .nav-link.dropdown-toggle {
                color: red !important;
            }
        <?php endif; ?>
        
          </style>


</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form>

            <li class="nav-item dropdown no-arrow">
    <a  class="nav-link" id="userDropdown" role="button"
        aria-haspopup="true" aria-expanded="false">
        <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
        </svg>
    </a>
  <!-- Dropdown - User Information -->
  <div class="dropdown-menu1  shadow animated--grow-in"
        aria-labelledby="userDropdown">
        <a class="dropdown-item1" href="profil.php">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profil
        </a>
        <a class="dropdown-item1" href="pesanan.php">
            <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
            Pesanan
        </a>
        <div class="dropdown-divider1"></div>
        <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Keluar
        </a>
    </div>
</li>
        </div>
</nav>
<section>
<div class="container-fluid">
    <div class="row">
        <!-- Kategori Sebelah Kiri -->
        <div class="col-lg-2"> <!-- Ubah ukuran kolom jika diperlukan -->
            <section class="honda-mobile-product-filters">
                <div class="widget-wrap">
                    <label for="categoryFilter" class="form-label" style="color: black;">Kategori Produk</label>
                    <form method="GET" action="produk.php">
                    <select id="categoryFilter" name="kategori" class="form-control category-filter">
    <?php
        include 'koneksi.php';
        $kategori_result = mysqli_query($koneksi, "SELECT DISTINCT kategori_produk FROM tb_sparepart");
        $selected = isset($_GET['kategori']) && $_GET['kategori'] === 'semua' ? 'selected' : '';
        echo "<option value='semua' $selected>Semua Produk &#9662;</option>"; // Option for "Semua Produk"
        while($kategori = mysqli_fetch_array($kategori_result)) {
            $selected = isset($_GET['kategori']) && $_GET['kategori'] === $kategori['kategori_produk'] ? 'selected' : '';
            echo "<option value='" . $kategori['kategori_produk'] . "' $selected>" . $kategori['kategori_produk'] . "</option>";
        }
    ?>
</select>
                    </form>
                </div>
            </section>
        </div>
    </div>
</div>


    <section class="container1">
        <div class="row ">
            <div class="col-lg-4 m-auto text-center">
                <h6 style="color: red;">All product is ready</h6>
            </div>
        </div>

        <div class="products-container1">
            <div class="row">
                <?php
                // Reset query result pointer
                mysqli_data_seek($result, 0);

                while ($row = mysqli_fetch_assoc($result)) {
                    $id_produk = $row['id_produk'];
                    $gambar_produk = $row['gambar_produk'];
                    $nama_produk = $row['nama_produk'];
                    $deskripsi = $row['deskripsi'];
                    $harga_produk = $row['harga_produk'];
                    $stok_produk = $row['jumlah_stok'];
                    $part_number = $row['part_number'];
                    $kategori_produk = $row['kategori_produk'];
                    $berat_produk = $row['berat_produk'];
                ?>
                <div class="col-md-3 mb-4">
                    <div class="product1" data-bs-toggle="modal" data-bs-target="#productModal<?php echo $id_produk; ?>">
                    <form action="tambahkeranjang.php" method="post">
                        <?php if (file_exists($gambar_produk)): ?>
                            <img src="<?php echo $gambar_produk; ?>" alt="<?php echo $nama_produk; ?>">
                        <?php else: ?>
                            <img src="path/to/default/image.jpg" alt="Default Image">
                        <?php endif; ?>
                        <h6><?php echo $nama_produk; ?></h6>
                        <div class="price1">Rp. <?php echo number_format($harga_produk, 0, ',', '.'); ?>
                        <button type="button" class="btn4 add-to-cart" data-product-id="<?php echo $id_produk; ?>">
    <i class="bi bi-cart-fill"></i>
</button>
                        </div>
                        </form>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="productModal<?php echo $id_produk; ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?php echo $id_produk; ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel<?php echo $id_produk; ?>">Detail Produk</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <!-- Periksa apakah file gambar ada -->
                                        <?php if (file_exists($gambar_produk)): ?>
                                            <img src="<?php echo $gambar_produk; ?>" alt="<?php echo $nama_produk; ?>" style="max-width: 100%; height: auto;">
                                        <?php else: ?>
                                            <img src="path/to/default/image.jpg" alt="Default Image" style="max-width: 100%; height: auto;">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-6">
                                        <h6 class="fw-bold fs-4"><?php echo $nama_produk; ?></h6>
                                        <p class="fs-5">Harga: Rp. <?php echo number_format($harga_produk, 0, ',', '.'); ?></p>
                                        <p class="fs-6">Stok: <?php echo $stok_produk; ?></p>
                                        <p class="fs-6">Nama Resmi Produk: <?php echo $deskripsi; ?></p>
                                        <p class="fs-6">Kode Part: <?php echo $part_number; ?></p>
                                        <p class="fs-6">Kategori: <?php echo $kategori_produk; ?></p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <form action="tambahkeranjang.php" method="post">
                                    <input type="hidden" name="product_id" value="<?php echo $id_produk; ?>">
                                    <button type="submit" class="btn btn-danger">Beli Sekarang</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                }
                ?>
            </div>
        </section>
    </div>
</div>

        
      <section>
      <footer id="footer" class="overflow-hidden padding-large">
      <div class="container-fluid">
        <div class="row">
          <div class="row d-flex flex-wrap justify-content-between">
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Quick Links</h5>
                <ul class="menu-list list-unstyled text-uppercase">
                  <li class="menu-item pb-2">
                    <a href="home.php">Home</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="tentangkami.php">Tentang Kami</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="produk.php">Produk</a>
                  </li>
                  <li class="menu-item pb-2">
                    <a href="profil.php">Akun</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Metode Pembayaran</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <img src="img/bankbri.png" alt="Pembayaran" width="80">
                  </ul>
                  <h5 class="widget-title pb-2">Metode Pengiriman</h5>
                  <ul class="list-unstyled">
                    <img src="img/jnt.jpg" alt="Pengiriman" width="80">
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-sm-6 pb-3">
              <div class="footer-menu text-uppercase">
                <h5 class="widget-title pb-2">Sosial Media</h5>
                <div class="social-links">
                  <ul class="list-unstyled">
                    <li class="pb-2">
                      <a href="#">Facebook</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Twitter</a>
                    </li>
                    <li class="pb-2">
                      <a href="#">Instagram</a>
                    </li>
                    <li>
                      <a href="#">Youtube</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-sm-6">
              <div class="footer-menu contact-item">
                <h5 class="widget-title text-uppercase pb-2">Hubungi Kami</h5>
                <p><a>+6282212345678</a></p>
                <h5 class="widget-title text-uppercase pb-2">Alamat</h5>
                <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
                <a href="https://www.google.com/maps/dir//Bedaro+Rampak,+Kec.+Tebo+Tengah,+Kabupaten+Tebo,+Jambi+37573/@-1.4626859,102.3438694,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x2e2ebf920b1d11e9:0xf9a5555e1f34bbda!2m2!1d102.4262714!2d-1.4626874?entry=ttu">
                <img src="img/maps.png" alt="Alamat Kami" width="150">
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer> 
      </section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Menangani klik pada tombol "Tambah ke Keranjang"
        $('.btn4').click(function() {
            // Ambil ID produk dari atribut data-product-id
            var productId = $(this).data('product-id');
            
            // Kirim permintaan AJAX ke tambahkankekeranjang.php
            $.ajax({
                url: 'tambahkeranjang.php',
                type: 'POST',
                data: {product_id: productId},
                success: function(response) {
                    // Tampilkan pesan dari respons
                    alert('Produk berhasil ditambahkan ke keranjang!');
                    
                    // Redirect ke halaman keranjang.php
                    window.location.href = 'keranjang.php';
                },
                error: function(xhr, status, error) {
                    // Tangani kesalahan jika terjadi
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('#categoryFilter').on('change', function() {
            $(this).closest('form').submit();
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>
