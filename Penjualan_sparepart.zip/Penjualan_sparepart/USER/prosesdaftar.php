<?php
// Sambungkan ke database (pastikan Anda telah mendefinisikan koneksi sebelumnya)
include 'koneksi.php'; // Sesuaikan dengan nama file koneksi Anda

// Ambil data yang dikirimkan melalui metode POST
$nama_pelanggan = $_POST['nama_pelanggan'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];
$email = $_POST['email'];
$password = $_POST['password'];

// Lakukan validasi data jika diperlukan
if (empty($nama_pelanggan) || empty($no_telp) || empty($alamat) || empty($email) || empty($password)) {
    header("Location: daftar.php?error=Semua field harus diisi!");
    exit();
}

// Pengecekan apakah email atau nomor telepon sudah terdaftar
$query_check = "SELECT * FROM tabel_pelanggan WHERE email = ? OR no_telp = ?";
$stmt_check = mysqli_prepare($koneksi, $query_check);
mysqli_stmt_bind_param($stmt_check, "ss", $email, $no_telp);
mysqli_stmt_execute($stmt_check);
$result_check = mysqli_stmt_get_result($stmt_check);

if (mysqli_num_rows($result_check) > 0) {
    header("Location: daftar.php?error=Email atau Nomor Telepon sudah digunakan!");
    exit();
}

// Simpan data ke dalam database, gunakan parameterized query untuk menghindari serangan SQL Injection
$query = "INSERT INTO tabel_pelanggan (nama_pelanggan, no_telp, alamat, email, password) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "sssss", $nama_pelanggan, $no_telp, $alamat, $email, $password);

if (mysqli_stmt_execute($stmt)) {
    // Ambil ID pelanggan yang baru saja disimpan
    $id_pelanggan = mysqli_insert_id($koneksi);
    // Jika data berhasil disimpan, alihkan ke halaman masuk dengan status sukses
    header("Location: masuk.php?id=$id_pelanggan&status=sukses");
    exit();
} else {
    // Jika terjadi kesalahan, Anda bisa menangani pesan kesalahan di sini
    header("Location: daftar.php?error=Gagal menyimpan data!");
    exit();
}

// Tutup koneksi ke database jika diperlukan
mysqli_stmt_close($stmt);
mysqli_stmt_close($stmt_check);
mysqli_close($koneksi);
?>
