<?php
session_start();
require 'koneksi.php';

// Fungsi untuk menambahkan produk ke keranjang
function addToCart($product_id) {
    global $koneksi;

    // Persiapkan query untuk mengambil data produk berdasarkan ID
    $query = "SELECT * FROM tb_sparepart WHERE id_produk = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();

    // Periksa apakah produk ditemukan
    if (!$product) {
        return false; // Produk tidak ditemukan
    }

    // Ekstrak informasi produk
    $product_name = $product['nama_produk'];
    $product_price = $product['harga_produk'];

    // Periksa apakah keranjang sudah ada dalam sesi
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Periksa apakah produk sudah ada di keranjang
    if (isset($_SESSION['cart'][$product_id])) {
        // Jika sudah ada, tambahkan jumlah produk
        $_SESSION['cart'][$product_id]['quantity'] += 1;
    } else {
        // Jika belum ada, tambahkan produk baru ke keranjang
        $_SESSION['cart'][$product_id] = [
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'quantity' => 1
        ];
    }

    return true; // Produk berhasil ditambahkan ke keranjang
}

// Periksa apakah ada ID produk yang dikirimkan melalui POST
if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];
    // Panggil fungsi addToCart untuk menambahkan produk ke keranjang
    if (addToCart($productId)) {
        // Jika berhasil, arahkan pengguna ke halaman keranjang.php
        header("Location: keranjang.php");
        exit(); // Pastikan tidak ada output lain sebelum redirect
    } else {
        echo "Produk tidak ditemukan";
    }
} else {
    echo "Tidak ada ID produk yang dikirimkan";
}
?>
