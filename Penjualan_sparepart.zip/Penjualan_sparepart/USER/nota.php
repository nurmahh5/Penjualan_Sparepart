<?php
// Include file koneksi database
include 'koneksi.php'; // Sesuaikan dengan nama file koneksi Anda

// Mulai sesi
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum, arahkan ke halaman login
    header("Location: masuk.php");
    exit();
}

// Ambil ID pengguna dari sesi
$id_pelanggan = $_SESSION['user_id'];

// Query untuk mengambil data pelanggan
$queryPelanggan = "SELECT nama_pelanggan, no_telp, email FROM tabel_pelanggan WHERE id_pelanggan = ?";
$stmtPelanggan = $koneksi->prepare($queryPelanggan);
$stmtPelanggan->bind_param("i", $id_pelanggan);
$stmtPelanggan->execute();
$resultPelanggan = $stmtPelanggan->get_result();
$rowPelanggan = $resultPelanggan->fetch_assoc();

// Periksa apakah nilai $_GET['id'] telah diset
$idTransaksi = isset($_GET['id']) ? $_GET['id'] : null;

// Pastikan $idTransaksi tidak null sebelum mengambil data dari database
if ($idTransaksi) {
    // Query untuk mengambil data transaksi
    $queryTransaksi = "SELECT * FROM tb_transaksi WHERE id_transaksi = ?";
    $stmtTransaksi = $koneksi->prepare($queryTransaksi);
    $stmtTransaksi->bind_param("i", $idTransaksi);
    $stmtTransaksi->execute();
    $resultTransaksi = $stmtTransaksi->get_result();
    $rowTransaksi = $resultTransaksi->fetch_assoc();

    // Query untuk mengambil data pembelian produk
    $queryPembelianProduk = "SELECT * FROM tb_pembelian_produk WHERE id_transaksi = ?";
    $stmtPembelianProduk = $koneksi->prepare($queryPembelianProduk);
    $stmtPembelianProduk->bind_param("i", $idTransaksi);
    $stmtPembelianProduk->execute();
    $resultPembelianProduk = $stmtPembelianProduk->get_result();
} else {
    // Jika $idTransaksi null, maka berikan pesan kesalahan atau redirect ke halaman lain
    echo "ID Transaksi tidak valid atau tidak ditemukan.";
    exit; // Hentikan eksekusi skrip
}
?>
<!doctype html>
<html lang="ar" dir="ltr">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
        rel="stylesheet">

    <title>Nota Pembelian</title>
    <style>
    .center-text {
        text-align: center;
    }

    .nota-table {
        width: 100%;
        margin-top: 20px;
    }

    .nota-table th,
    .nota-table td {
        padding: 10px;
        border: 1px solid #ddd;
    }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">TEGUH RAYA MOTOR</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item nav-item-home">
            <a class="nav-link active" aria-current="page" href="home.php">Home</a>
            </li>
            <li class="nav-item nav-item-tentangkami">
            <a class="nav-link" href="tentangkami.php">TENTANG KAMI</a>
            </li>
            <li class="nav-item nav-item-produk">
            <a class="nav-link" href="produk.php">PRODUK</a>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" id="navbarDropdown"  role="button" data-bs-toggle="dropdown" aria-expanded="false">Akun</a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li><a class="dropdown-item" href="masuk.php">Masuk</a></li>
                <li><a class="dropdown-item" href="daftar.php">Daftar</a></li>
            </ul>
            </li>
        </ul>
        </div>
            <button class="btn0" onclick="location.href='keranjang.php'">
            <div class="d-flex align-items-center">
                <i class="bi bi-cart-fill px-1"></i>
            </button>
            <form action="search_produk.php" method="GET" class="d-flex">
    <input class="me-2 px-3 search" type="search" placeholder="Cari Produk" aria-label="Search" name="keyword">
    <button class="btn1" type="submit">Cari</button>
</form> 
            <li class="nav-item dropdown no-arrow">
    <a  class="nav-link" id="userDropdown" role="button"
        aria-haspopup="true" aria-expanded="false">
        <svg id="accountIcon" xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16" style="margin: 8px;">
            <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
            <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
        </svg>
    </a>
    <!-- Dropdown - User Information -->
    <div class="dropdown-menu1  shadow animated--grow-in"
        aria-labelledby="userDropdown">
        <a class="dropdown-item1" href="profil.php">
            <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
            Profil
        </a>
        <a class="dropdown-item1" href="pesanan.php">
            <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
            Pesanan
        </a>
        <div class="dropdown-divider1"></div>
        <a class="dropdown-item" href="logout.php" data-toggle="modal" data-target="#logoutModal">
            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
            Keluar
        </a>
    </div>
</li>
        </div>
</nav>

</head>

<body>
<section>
<div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="border-end bg-white" id="sidebar-wrapper">
            <div class="list-group list-group-flush">
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="home.php">Home</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="profil.php">Profil</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="pesanan.php">Pesanan</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="produk.php">Produk</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="tentangkami.php">Tentang Kami</a>
            </div>
        </div>
    <div class="container mt-5">
        <h2>Nota Pembelian</h2>
        <div class="row" style="margin-bottom-top: 10px;">
            <div class="col-md-4">
                <h5>Detail Transaksi</h5>
                <p>No Pesanan: <?php echo $rowTransaksi['id_transaksi']; ?></p>
                <p>Tanggal: <?php echo $rowTransaksi['tanggal_transaksi']; ?></p>
                <p>Total Bayar: <?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></p>
                <!-- Sisipkan detail transaksi lainnya di sini -->
            </div>
            <div class="col-md-4">
                <h5>Pelanggan</h5>
                <p>Nama: <?php echo $rowPelanggan['nama_pelanggan']; ?></p>
                <p>No Telp: <?php echo $rowPelanggan['no_telp']; ?></p>
                <p>Email: <?php echo $rowPelanggan['email']; ?></p>
                <!-- Sisipkan detail transaksi lainnya di sini -->
            </div>
            <div class="col-md-4">
                <h5>Pengiriman</h5>
                <p>Ongkos Kirim: <?php echo 'Rp. ' . number_format($rowTransaksi['ongkir'], 0, ',', '.'); ?></p>
                <p>Ekspedisi: <?php echo $rowTransaksi['ekspedisi']; ?></p>
                <p>Alamat: 
                    <?php echo $rowTransaksi['provinsi']; ?>
                    <?php echo $rowTransaksi['distrik']; ?>
                    <?php echo $rowTransaksi['alamat_pengiriman']; ?>
                </p>
                <p>Catatan: <?php echo $rowTransaksi['catatan']; ?></p>
                <!-- Sisipkan detail transaksi lainnya di sini -->
            </div>
        </div>
        <table class="nota-table">
    <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Berat</th>
                        <th>Jumlah</th>
                        <th>Subberat</th>
                        <th>Subtotal</th>
                        <th>Ongkir</th>
                        <th>Total Bayar</th>
                    </tr>
    </thead>
    <tbody>
        <?php 
        // Inisialisasi variabel nomor
        $nomor = 1;
        
        while ($rowPembelianProduk = $resultPembelianProduk->fetch_assoc()) : ?>
                    <tr>
                        <!-- Nomor -->
                        <td><?php echo $nomor++; ?></td>
                        <td style="display: none;"><input type="hidden" name="id_produk[]" value="<?php echo $rowPembelianProduk['id_produk']; ?>"></td>
                        <td><?php echo $rowPembelianProduk['nama_produk']; ?></td>
                        <td><?php echo 'Rp. ' . number_format($rowPembelianProduk['harga_produk'], 0, ',', '.'); ?></td>
                        <td><?php echo $rowPembelianProduk['berat_produk']. " gr"; ?></td>
                        <td><?php echo $rowPembelianProduk['jumlah']; ?></td>
                        <td><?php echo $rowPembelianProduk['subberat']. " gr"; ?></td>
                        <td><?php echo 'Rp. ' .number_format($rowPembelianProduk['subharga'], 0, ',', '.'); ?></td>
                        <td> <?php echo 'Rp. ' . number_format($rowTransaksi['ongkir'], 0, ',', '.'); ?></td>
                        <td><?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></td>
                    </tr>
        <?php endwhile; ?>
    </tbody>
</table>

    </div>
    </section>

    <!-- Optional JavaScript -->
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-7CZwN3B4XLBcr2pkMWTNSuEN51G6Z1dtdTNCG5SQOeKfUIwvZVzQFJiX+IEo4aNr"
        crossorigin="anonymous"></script>
</body>

</html>
