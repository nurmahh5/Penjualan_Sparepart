<?php
// Mulai sesi
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika tidak, alihkan kembali ke halaman home.php atau halaman lain yang sesuai
    header("Location: home.php");
    exit();
}

// Periksa apakah metode permintaan adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Hapus semua data sesi
    session_unset();
    // Hancurkan sesi
    session_destroy();
    // Alihkan ke halaman home setelah logout
    header("Location: home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
</head>
<body>
    <script>
        // Tampilkan pesan konfirmasi sebelum logout
        if (confirm("Anda yakin ingin logout?")) {
            // Jika pengguna mengonfirmasi logout, kirimkan permintaan POST ke logout.php
            const form = document.createElement('form');
            form.method = 'post';
            form.action = 'logout.php';
            document.body.appendChild(form);
            form.submit();
        } else {
            // Jika pengguna membatalkan logout, arahkan kembali ke halaman sebelumnya atau lakukan tindakan lain yang sesuai
            history.back();
        }
    </script>
</body>
</html>
