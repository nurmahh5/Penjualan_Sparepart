<?php
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

// cek koneksi
if (mysqli_connect_errno()){
    echo "koneksi database gagal : " . mysqli_connect_errno();
}

?>