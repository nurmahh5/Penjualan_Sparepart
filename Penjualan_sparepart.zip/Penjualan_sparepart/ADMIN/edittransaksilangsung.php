
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- jQuery and jQuery UI for autocomplete -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                </div>
                <div class="sidebar-brand-text mx-3">TEGUH RAYA MOTOR</div>
            </a>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>DASHBOARD</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <!-- Nav Item - Master Data Collapse Menu -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseMasterData"
                    aria-expanded="true" aria-controls="collapseMasterData">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>MASTER DATA</span>
                </a>
                <div id="collapseMasterData" class="collapse" aria-labelledby="headingMasterData"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Data Pelanggan</a>
                        <a class="collapse-item" href="barang.php">Data Barang</a>
                        <a class="collapse-item" href="penjualan.php">Data Penjualan</a>
                    </div>
                </div>
            </li> -->
            <!-- Nav Item - Transaksi Collapse Menu -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTransaksi"
                    aria-expanded="true" aria-controls="collapseTransaksi">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>TRANSAKSI</span>
                </a>
                <div id="collapseTransaksi" class="collapse" aria-labelledby="headingTransaksi"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="transaksilangsung.php">Transaksi Langsung</a>
                        <a class="collapse-item" href="transaksitidaklangsung.php">Transaksi Tidak Langsung</a>
                    </div>
                </div>
            </li> -->
            <!-- Nav Item - Laporan -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" href="laporan.php" ata-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-file"></i>
                    <span>LAPORAN</span>
                </a>
            </li> -->
            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">
            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <h1 class="h3 mb-2 text-gray-800">Tambah Data Transaksi</h1>
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <form action="ttransaksilangsung.php" method="POST">
                                <!-- Nama Produk, Harga, dan Jumlah Item -->
                                <div id="produk_container">
                                    <div class="produk-item mb-3">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control nama_produk" name="nama_produk[]" placeholder="Nama Produk" value="<?php echo $row['nama_produk']; ?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control harga_produk" name="harga_produk[]" placeholder="Harga" value="<?php echo $row['harga_produk']; ?>">
                                            </div>
                                            <!-- Jumlah Item -->
                                            <div class="col-sm-4">
                                                <input type="number" class="form-control jumlah_item" name="jumlah_item[]" placeholder="Jumlah" value="<?php echo $row['jumlah_item']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tombol Tambah Produk -->
                                <div class="row mb-3">
                                    <div class="col-sm-12">
                                        <button type="button" class="btn btn-danger" onclick="tambahProduk()"><i class="fas fa-plus"></i> Produk</button>
                                    </div>
                                </div>
                                <!-- Total Bayar -->
                                <div class="row mb-3">
                                    <label for="jumlah_bayar" class="col-sm-2 col-form-label">Total Bayar</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="jumlah_bayar" name="jumlah_bayar" readonly value="<?php echo $row['total_bayar']; ?>">
                                    </div>
                                </div>
                                <!-- Tanggal -->
                                <div class="row mb-3">
                                    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo $row['tanggal']; ?>">
                                    </div>
                                </div>
                                <!-- Metode Pembayaran -->
                                <div class="row mb-3">
                                    <label for="metode_pembayaran" class="col-sm-2 col-form-label">Metode Pembayaran</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="metode_pembayaran" name="metode_pembayaran">
                                            <option value="transfer" <?php if($row['metode_pembayaran'] == 'transfer') echo 'selected'; ?>>Transfer</option>
                                            <option value="Cash" <?php if($row['metode_pembayaran'] == 'Cash') echo 'selected'; ?>>Cash</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Keterangan Bayar -->
                                <div class="row mb-3">
                                    <label for="status_bayar" class="col-sm-2 col-form-label">Keterangan</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="status_bayar" name="status_bayar">
                                            <option value="lunas" <?php if($row['status_bayar'] == 'lunas') echo 'selected'; ?>>Lunas</option>
                                            <option value="belum lunas" <?php if($row['status_bayar'] == 'belum lunas') echo 'selected'; ?>>Belum Lunas</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Tombol Tambah Data -->
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-danger">Simpan Perubahan</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Script for autocomplete and other custom functions -->
    <script>
        // JavaScript functions here
    </script>
</body>

</html>
