<?php

include 'koneksi.php';

// Mengambil data dari formulir
$id_produk = $_POST['id_produk'];
$part_number = $_POST['part_number'];
$nama_produk = $_POST['nama_produk'];
$deskripsi = $_POST['deskripsi'];
$kategori_produk = $_POST['kategori_produk'];
$harga_produk = $_POST['harga_produk'];
$jumlah_stok = $_POST['jumlah_stok'];
$berat_produk = $_POST['berat_produk'];

$gambar_name = $_FILES['gambar']['name'];
$gambar_tmp = $_FILES['gambar']['tmp_name'];
$gambar_path = "uploads/" . $gambar_name;

// Periksa apakah folder 'uploads' ada, jika tidak, buat folder tersebut
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

if (move_uploaded_file($gambar_tmp, $gambar_path)) {
    $query = "INSERT INTO tb_sparepart (id_produk, part_number, nama_produk, deskripsi, kategori_produk, harga_produk, jumlah_stok, gambar_produk, berat_produk) 
              VALUES ('$id_produk', '$part_number', '$nama_produk', '$deskripsi', '$kategori_produk', '$harga_produk', '$jumlah_stok', '$gambar_path', '$berat_produk')";

    if (mysqli_query($koneksi, $query)) {
        header("Location: barang.php"); // Redirect ke halaman tabel barang setelah berhasil tambah barang
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
} else {
    echo "Maaf, terjadi kesalahan saat mengunggah file gambar.";
}

// Menutup koneksi
mysqli_close($koneksi);
?>
