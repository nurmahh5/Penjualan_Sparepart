<?php
include 'koneksi.php';

// Ambil id penjualan dari parameter URL
if (isset($_GET['id'])) {
    $id_penjualan = $_GET['id'];

    // Query untuk menghapus data penjualan berdasarkan id
    $query = "DELETE FROM tabel_penjualan WHERE id_penjualan = ?";

    // Persiapkan statement
    $stmt = mysqli_prepare($koneksi, $query);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, 'i', $id_penjualan);

    // Eksekusi statement
    if (mysqli_stmt_execute($stmt)) {
        // Jika berhasil dihapus, redirect ke halaman penjualan.php
        header("Location: penjualan.php");
        exit();
    } else {
        // Jika terjadi error, tampilkan pesan error
        echo "Error: " . mysqli_error($koneksi);
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
} else {
    echo "ID penjualan tidak diberikan.";
    exit();
}

// Tutup koneksi database
mysqli_close($koneksi);
?>
