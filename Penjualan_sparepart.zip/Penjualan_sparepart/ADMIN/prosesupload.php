

<?php

include 'koneksi.php';

// Mengambil data dari formulir
$id_produk = $_POST['id_produk'];
$part_number = $_POST['part_number'];
$nama_produk = $_POST['nama_produk'];
$deskripsi = $_POST['deskripsi'];
$harga_produk = $_POST['harga_produk'];
$jumlah_stok = $_POST['jumlah_stok'];

$gambar_name = $_FILES['gambar']['name'];
    $gambar_tmp = $_FILES['gambar']['tmp_name'];
    $gambar_path = "uploads/" . $gambar_name;

    move_uploaded_file($tmp, $path);


        $query = "INSERT INTO tb_sparepart VALUES ('$id_produk', '$part_number', '$nama_produk', '$deskripsi', '$harga_produk', '$jumlah_stok', '$gambar_produk')";

        
        mysqli_query($koneksi, $query);

// Redirect ke halaman admin setelah proses upload selesai
header("location:barang.php");
exit(); // Pastikan proses script berhenti setelah melakukan redirect

?>
 
