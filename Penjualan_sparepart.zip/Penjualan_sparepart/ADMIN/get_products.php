<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

// Periksa koneksi
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil nilai term dari permintaan AJAX
$term = isset($_GET['term']) ? $_GET['term'] : '';

// Query untuk mengambil nama produk dari tabel tb_sparepart
$query = "SELECT nama_produk FROM tb_sparepart WHERE nama_produk LIKE '%" . mysqli_real_escape_string($koneksi, $term) . "%'";
$result = mysqli_query($koneksi, $query);

// Siapkan array untuk menyimpan hasil
$produk_arr = array();

// Loop melalui hasil query dan tambahkan ke array
while ($row = mysqli_fetch_assoc($result)) {
    $produk_arr[] = $row['nama_produk'];
}

// Mengembalikan hasil dalam format JSON
echo json_encode($produk_arr);

// Tutup koneksi mysqli
mysqli_close($koneksi);
?>
