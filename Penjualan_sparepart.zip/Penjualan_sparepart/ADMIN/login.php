<?php
session_start();

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

// Periksa koneksi
if (mysqli_connect_errno()) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Inisialisasi pesan error
$error_message = "";

// Periksa apakah form login dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data username dan password dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa apakah username dan password sesuai
    $query = "SELECT * FROM tb_admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) == 1) {
        // Jika sesuai, set session dan arahkan ke halaman index.php
        $_SESSION['admin'] = true; // Set session 'admin'
        $_SESSION['success_message'] = "Login berhasil!"; // Tambahkan pesan sukses
        header("Location: index.php");
    } else {
        // Jika tidak sesuai, tampilkan pesan error
        $error_message = "Username atau password salah!";
    }
}

// Tutup koneksi ke database
mysqli_close($koneksi);
?>

<!DOCTYPE html>
<html lang="en">
<style>
    .field-icon {
    float: right;
    margin-top: -35px;
    margin-right: 20px;
    position: relative;
    z-index: 2;
}

</style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-danger">
    <div class="container">
        <!-- Outer Row -->
        <div class="row justify-content-center">
        <div class="col-lg-8">                
            <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-5 d-flex align-items-center">
                                <img src="img/mekanik3.png" class="img-fluid" alt="Placeholder Image">
                            </div>
                            <div class="col-lg-7">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Silahkan Login!</h1>
                                    </div>
                                    <form class="user" method="POST" action="login.php">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="username" placeholder="Masukkan Username..." required>
                                        </div>
                                        <div class="form-group">
                                        <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Password" required>
                                        <span toggle="#password" class="fa fa-fw fa-eye field-icon toggle-password text-dark"></span>
                                        </div>
                                        <button type="submit" class="btn btn-danger btn-user btn-block">Login</button>
                                    </form>
                                    <hr>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>



 <!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Custom script for login -->
<script>
    <?php if ($error_message != "") : ?>
        // If there is an error message, display alert
        $(document).ready(function() {
            alert("<?php echo $error_message; ?>");
        });
    <?php endif; ?>
</script>
<script>
    // Fungsi untuk menampilkan atau menyembunyikan password ketika ikon mata diklik
    $(".toggle-password").click(function() {
        $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
            input.attr("type", "text");
        } else {
            input.attr("type", "password");
        }
    });
</script>

</body>

</html>
