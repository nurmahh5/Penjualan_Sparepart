<?php
// Include file koneksi.php
include 'koneksi.php';

// Periksa apakah parameter id_barang telah dikirimkan melalui URL
if(isset($_GET['id'])) {
    // Tangkap id_barang dari parameter URL
    $id_produk = $_GET['id'];

    // Query untuk menghapus data barang berdasarkan id_barang
    $query = "DELETE FROM tb_sparepart WHERE id_produk = ?";

    // Persiapkan statement
    $stmt = mysqli_prepare($koneksi, $query);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, 'i', $id_produk);

    // Lakukan penghapusan data
    if(mysqli_stmt_execute($stmt)) {
        // Jika berhasil dihapus, redirect ke halaman barang.php
        header("Location: barang.php");
        exit();
    } else {
        // Jika terjadi error, tampilkan pesan error
        echo "Error: " . mysqli_error($koneksi);
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
} else {
    // Jika parameter id_barang tidak diberikan, tampilkan pesan error
    echo "ID barang tidak diberikan.";
}

// Tutup koneksi database
mysqli_close($koneksi);
?>
