<?php

include "koneksi.php";

        if (isset($_POST['submit'])) {
            $id_produk = $_POST['id_produk'];
            $part_number = $_POST['part_number'];
            $nama_produk = $_POST['nama_produk'];
            $deskripsi = $_POST['deskripsi'];
            $harga_produk = $_POST['harga_produk'];
            $jumlah_stok = $_POST['jumlah_stok'];

            // Mengambil data gambar
            $gambar_name = $_FILES['gambar']['name'];
            $gambar_tmp = $_FILES['gambar']['tmp_name'];
            $gambar_path = "uploads/" . $gambar_name;

            // Pindahkan file gambar ke lokasi yang diinginkan
            if ($gambar_name) {
                move_uploaded_file($gambar_tmp, $gambar_path);
                $gambar_query = ", gambar_produk='$gambar_name'";
            } else {
                $gambar_query = "";
            }

            $query = "UPDATE buku 
                      SET part_number='$part_number', nama_produk='$nama_produk', deskripsi='$deskripsi', harga_produk='$harga_produk', jumlah_stok='$jumlah_stok', $gambar_query
                      WHERE id_produk='$id_produk'";

            if (mysqli_query($koneksi, $query)) {
                echo "<script> alert('Data Berhasil Di Update')</script>";
                header("refresh:0;url=barang.php");
            } else {
                echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
            }
        } else {
            if (isset($_GET['id_produk'])) {
                $id_produk = $_GET['id_produk'];
                $query = "SELECT * FROM tb_sparepart WHERE id_produk='$id_produk'";
                $result = mysqli_query($koneksi, $query);
                $data = mysqli_fetch_assoc($result);
            }}
        ?>