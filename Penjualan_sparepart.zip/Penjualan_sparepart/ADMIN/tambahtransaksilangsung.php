<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- jQuery and jQuery UI for autocomplete -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>


    <script>
  $(document).ready(function() {
    $(".nama_produk").autocomplete({
        source: function(request, response) {
            $.ajax({
                url: "get_products.php",
                dataType: "json",
                data: {
                    term: request.term
                },
                success: function(data) {
                    response(data);
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + status + " " + error);
                }
            });
        },
        minLength: 1, // Jumlah minimum karakter sebelum pencarian dimulai
        select: function(event, ui) {
            var selectedProduct = ui.item.value;
            // Mendapatkan elemen input harga_produk terkait dengan produk yang dipilih
            var hargaInput = $(this).closest('.produk-item').find('.harga_produk');
            // Lakukan permintaan AJAX untuk mendapatkan harga produk
            $.ajax({
                url: "get_product_price.php",
                dataType: "json",
                data: {
                    nama_produk: selectedProduct
                },
                success: function(data) {
                    // Update nilai input harga_produk dengan harga yang diterima dari server
                    hargaInput.val(data.harga_produk);
                    // Panggil fungsi untuk memperbarui total bayar
                    updateTotalBayar();
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + status + " " + error);
                }
            });
        }
    });
});

    </script>
</head>

<body id="page-top">
        <!-- Page Wrapper -->
        <div id="wrapper">

<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
        </div>
        <div class="sidebar-brand-text mx-3">TEGUH RAYA MOTOR</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>DASHBOARD</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

     <!-- Nav Item - Master Data Collapse Menu -->
     <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseMasterData"
                    aria-expanded="true" aria-controls="collapseMasterData">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>MASTER DATA</span>
                </a>
                <div id="collapseMasterData" class="collapse" aria-labelledby="headingMasterData"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Data Pelanggan</a>
                        <a class="collapse-item" href="barang.php">Data Barang</a>
                        <a class="collapse-item" href="penjualan.php">Data Penjualan</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Transaksi Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTransaksi"
                    aria-expanded="true" aria-controls="collapseTransaksi">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>TRANSAKSI</span>
                </a>
                <div id="collapseTransaksi" class="collapse" aria-labelledby="headingTransaksi"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="transaksilangsung.php">Transaksi Langsung</a>
                        <a class="collapse-item" href="transaksitidaklangsung.php">Transaksi Tidak Langsung</a>
                    </div>
                </div>
            </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="laporan.php" ata-target="#collapseUtilities"
            aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-fw fa-file"></i>
            <span>LAPORAN</span>
        </a>
    </li>


            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
      
        
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <h1 class="h3 mb-2 text-gray-800">Tambah Data Transaksi</h1>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">2+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i>
                                <!-- Counter - Messages -->
                                <span class="badge badge-danger badge-counter">1</span>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                                <h6 class="dropdown-header">
                                    Message Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_1.svg"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div class="font-weight-bold">
                                        <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                            problem I've been having.</div>
                                        <div class="small text-gray-500">Emily Fowler · 58m</div>
                                    </div>
                                </a>
                  
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <form action="ttransaksilangsung.php" method="POST">
                                <!-- Nama Produk, Harga, dan Jumlah Item -->
                                <div id="produk_container">
                                    <div class="produk-item mb-3">
                                        <div class="row">
                                            <div class="col-sm-4">
                                            <input type="text" class="form-control nama_produk" name="nama_produk[]" placeholder="Nama Produk" onchange="getHarga(this)">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="text" class="form-control harga_produk" name="harga_produk[]" placeholder="Harga" oninput="updateTotalBayar()">
                                            </div>
                                            <!-- Jumlah Item -->
                                            <div class="col-sm-4">
                                                <input type="number" class="form-control jumlah_item" name="jumlah_item[]" placeholder="Jumlah" oninput="updateTotalBayar()">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tombol Tambah Produk -->
                                <div class="row mb-3">
                                    <div class="col-sm-12">
                                        <button type="button" class="btn btn-danger" onclick="tambahProduk()"><i class="fas fa-plus"></i> Produk</button>
                                    </div>
                                </div>
                                <!-- Total Bayar -->
                                <div class="row mb-3">
                                    <label for="jumlah_bayar" class="col-sm-2 col-form-label">Total Bayar</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="jumlah_bayar" name="jumlah_bayar" readonly>
                                    </div>
                                </div>
                                <!-- Tanggal -->
                                <div class="row mb-3">
                                    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" id="tanggal" name="tanggal">
                                    </div>
                                </div>
                                <!-- Metode Pembayaran -->
                                <div class="row mb-3">
                                    <label for="metode_pembayaran" class="col-sm-2 col-form-label">Metode Pembayaran</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="metode_pembayaran" name="metode_pembayaran">
                                            <option>- Metode Pembayaran -</option>
                                            <option value="transfer">Transfer</option>
                                            <option value="Cash">Cash</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Keterangan Bayar -->
                                <div class="row mb-3">
                                    <label for="status_bayar" class="col-sm-2 col-form-label">Keterangan</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="status_bayar" name="status_bayar">
                                            <option value="lunas">- Keterangan Bayar -</option>
                                            <option value="lunas">Lunas</option>
                                            <option value="belum lunas">Belum Lunas</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Tombol Tambah Data -->
                                <div class="form-group row">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-danger">Tambah Data</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End of Main Content -->
            </div>
        </div>
    </div>

    <script>
        function tambahProduk() {
            const produkContainer = document.getElementById('produk_container');
            const produkCount = produkContainer.getElementsByClassName('produk-item').length + 1;
            const produkItem = document.createElement('div');
            produkItem.classList.add('produk-item', 'mb-3');
            produkItem.innerHTML = `
                <div class="row">
                    <div class="col-sm-4">
                    <input type="text" class="form-control nama_produk" name="nama_produk[]" placeholder="Nama Produk" onchange="getHarga(this)">
                    </div>
                    <div class="col-sm-4">
                        <input type="text" class="form-control harga_produk" name="harga_produk[]" placeholder="Harga" oninput="updateTotalBayar()">
                    </div>
                    <div class="col-sm-4">
                        <input type="number" class="form-control jumlah_item" name="jumlah_item[]" placeholder="Jumlah" oninput="updateTotalBayar()">
                    </div>
                </div>
            `;
            produkContainer.appendChild(produkItem);

            // Initialize autocomplete on the new input
            $(".nama_produk").autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: "get_products.php",
                        dataType: "json",
                        data: {
                            term: request.term
                        },
                        success: function(data) {
                            response(data);
                        },
                        error: function(xhr, status, error) {
                            console.error("Error: " + status + " " + error);
                        }
                    });
                },
                minLength: 1
            });
        }

        function getHarga(input) {
        var namaProduk = input.value;
        var hargaInput = input.closest('.row').querySelector('.harga_produk');

        // Lakukan permintaan AJAX untuk mendapatkan harga produk
        $.ajax({
            url: "get_product_price.php",
            method: "POST",
            data: { nama_produk: namaProduk },
            dataType: "json",
            success: function(data) {
                // Jika permintaan berhasil, update nilai input harga_produk
                hargaInput.value = data.harga;
                updateTotalBayar();
            },
            error: function(xhr, status, error) {
                console.error("Error: " + status + " " + error);
            }
        });
    }

        function updateTotalBayar() {
            const produkItems = document.querySelectorAll('.produk-item');
            let totalBayar = 0;

            produkItems.forEach(item => {
                const harga = parseFloat(item.querySelector('.harga_produk').value) || 0;
                const jumlah = parseInt(item.querySelector('.jumlah_item').value) || 0;
                totalBayar += harga * jumlah;
            });

            document.getElementById('jumlah_bayar').value = totalBayar.toFixed(0);
        }
    </script>
</body>
</html>
