<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "penjualan_sparepart");

if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Periksa apakah 'nama_produk' terkirim melalui POST
if(isset($_POST['nama_produk'])) {
    // Ambil nilai nama_produk dari POST
    $nama_produk = $_POST['nama_produk'];

    // Query untuk mengambil harga_produk dari tabel tb_sparepart berdasarkan nama_produk
    $query = "SELECT harga_produk FROM tb_sparepart WHERE nama_produk = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "s", $nama_produk);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $harga_produk);
    mysqli_stmt_fetch($stmt);

    // Mengambil harga dari hasil query
    $result = ["harga" => $harga_produk];

    // Mengembalikan hasil dalam format JSON
    header('Content-Type: application/json');
    echo json_encode($result);

    // Tutup koneksi mysqli
    mysqli_stmt_close($stmt);
} else {
    // Jika 'nama_produk' tidak terkirim, kirim respons JSON kosong
    echo json_encode([]);
}

mysqli_close($koneksi);
?>
