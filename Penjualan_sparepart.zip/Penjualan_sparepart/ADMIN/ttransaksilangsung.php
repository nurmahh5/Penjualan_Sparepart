<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal = $_POST['tanggal'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    $status_bayar = $_POST['status_bayar'];
    $total_bayar = $_POST['jumlah_bayar'];
    $tipe_transaksi = "langsung"; // Nilai tipe_transaksi diset langsung di sini

    // Insert data into tb_transaksi
    $query_transaksi = "INSERT INTO tb_transaksi (tanggal_transaksi, metode_pembayaran, status_pembayaran, total_bayar, tipe_transaksi) VALUES ('$tanggal', '$metode_pembayaran', '$status_bayar', '$total_bayar', '$tipe_transaksi')";
    if (mysqli_query($koneksi, $query_transaksi)) {
        $id_transaksi = mysqli_insert_id($koneksi);

        // Insert data into tb_pembelian_produk
        $nama_produk = $_POST['nama_produk'];
        $harga_produk = $_POST['harga_produk'];
        $jumlah_item = $_POST['jumlah_item'];

        for ($i = 0; $i < count($nama_produk); $i++) {
            $nama = $nama_produk[$i];
            $harga = $harga_produk[$i];
            $jumlah = $jumlah_item[$i];
            $subberat = 0; // Hitung berat produk sesuai dengan logika bisnis Anda
            $subharga = $harga * $jumlah;

            $query_pembelian_produk = "INSERT INTO tb_pembelian_produk (id_transaksi, nama_produk, harga_produk, jumlah, subberat, subharga) VALUES ('$id_transaksi', '$nama', '$harga', '$jumlah', '$subberat', '$subharga')";
            mysqli_query($koneksi, $query_pembelian_produk);
        }

        echo "<script>
                alert('Transaksi berhasil ditambahkan.');
                window.location.href = 'transaksilangsung.php';
              </script>";
    } else {
        echo "<script>
                alert('Error: " . mysqli_error($koneksi) . "');
                window.location.href = 'transaksilangsung.php';
              </script>";
    }
}
?>
