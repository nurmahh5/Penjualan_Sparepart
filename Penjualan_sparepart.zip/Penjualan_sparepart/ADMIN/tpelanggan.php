<?php

include 'koneksi.php';

$id_pelanggan = $_POST['id_pelanggan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];
$email = $_POST['email'];
$password = $_POST['password'];

// Mengecek apakah id pelanggan, nama pelanggan, no_telp, alamat, emial dan password  kosong atau tidak
if(empty($id_pelanggan) || empty($nama_pelanggan) || empty($no_telp) || empty($alamat) || empty($email) || empty($password)) {
    if(empty($id_pelanggan)) {
        echo "id Pelanggan Tidak Boleh Kosong<br>";
    }
    if(empty($nama_pelanggan)) {
        echo "Nama Pelanggan Tidak Boleh Kosong<br>";
    }
    if(empty($no_telp)) {
        echo "No Telp Tidak Boleh Kosong<br>";
    }
    if(empty($alamat)) {
        echo "Alamat Tidak Boleh Kosong<br>";
    }
    if(empty($email)) {
        echo "Email Tidak Boleh Kosong<br>";
    }
    if(empty($password)) {
        echo "Password Tidak Boleh Kosong<br>";
    } 
} else {
    $query = "INSERT INTO tabel_pelanggan VALUES ('$id_pelanggan', '$nama_pelanggan', '$no_telp', '$alamat', '$email', '$password')";

    if (mysqli_query($koneksi, $query)) {
        echo "Data telah ditambahkan";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
}

mysqli_close($koneksi);
header("location:pelanggan.php");
?>
