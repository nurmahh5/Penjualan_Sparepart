<?php
// Include file koneksi database
include 'koneksi.php'; // Sesuaikan dengan nama file koneksi Anda

// Periksa apakah nilai $_GET['id'] telah diset
$idTransaksi = isset($_GET['id']) ? $_GET['id'] : null;

// Pastikan $idTransaksi tidak null sebelum mengambil data dari database
if ($idTransaksi) {
    // Query untuk mengambil data transaksi
    $queryTransaksi = "SELECT * FROM tb_transaksi WHERE id_transaksi = ?";
    $stmtTransaksi = $koneksi->prepare($queryTransaksi);
    $stmtTransaksi->bind_param("i", $idTransaksi);
    $stmtTransaksi->execute();
    $resultTransaksi = $stmtTransaksi->get_result();
    $rowTransaksi = $resultTransaksi->fetch_assoc();

    // Ambil ID pelanggan dari transaksi
    $idPelanggan = $rowTransaksi['id_pelanggan'];

    // Query untuk mengambil data pelanggan berdasarkan ID pelanggan dari transaksi
    $queryPelanggan = "SELECT nama_pelanggan, no_telp, email FROM tabel_pelanggan WHERE id_pelanggan = ?";
    $stmtPelanggan = $koneksi->prepare($queryPelanggan);
    $stmtPelanggan->bind_param("i", $idPelanggan);
    $stmtPelanggan->execute();
    $resultPelanggan = $stmtPelanggan->get_result();
    $rowPelanggan = $resultPelanggan->fetch_assoc();

    // Query untuk mengambil data pembelian produk
    $queryPembelianProduk = "SELECT * FROM tb_pembelian_produk WHERE id_transaksi = ?";
    $stmtPembelianProduk = $koneksi->prepare($queryPembelianProduk);
    $stmtPembelianProduk->bind_param("i", $idTransaksi);
    $stmtPembelianProduk->execute();
    $resultPembelianProduk = $stmtPembelianProduk->get_result();
} else {
    // Jika $idTransaksi null, maka berikan pesan kesalahan atau redirect ke halaman lain
    echo "ID Transaksi tidak valid atau tidak ditemukan.";
    exit; // Hentikan eksekusi skrip
}
?>
         
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Detail Transaksi</title>
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .receipt {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-family: 'Nunito', sans-serif;
        }
        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
        }
        .receipt-header h2 {
            margin: 0;
        }
        .receipt-header p {
            margin: 5px 0;
        }
        .receipt-table {
            width: 100%;
            border-collapse: collapse;
        }
        .receipt-table th, .receipt-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        .receipt-table th {
            background-color: #f2f2f2;
        }
        .receipt-footer {
            text-align: right;
            margin-top: 20px;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15"></div>
                <div class="sidebar-brand-text mx-3">TEGUH RAYA MOTOR</div>
            </a>
            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>DASHBOARD</span></a>
            </li>
            <!-- Divider -->
            <hr class="sidebar-divider">
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-folder"></i>
                    <span>MASTER DATA</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="pelanggan.php">Data Pelanggan</a>
                        <a class="collapse-item" href="barang.php">Data Barang</a>
                        <a class="collapse-item" href="penjualan.php">Data Penjualan</a>
                    </div>
                </div>
            </li>
            <!-- Nav Item - Utilities Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>TRANSAKSI</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="transaksilangsung.php">Transaksi Langsung</a>
                        <a class="collapse-item" href="transaksitidaklangsung.php">Transaksi Tidak Langsung</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="laporan.php" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-file"></i>
                    <span>LAPORAN</span>
                </a>
            </li>
        </ul>

        <div class="container mt-5">
    <a href="transaksitidaklangsung.php" class="btn btn-danger mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>
            <h2>Nota Pembelian</h2>
            <div class="row" style="margin-bottom-top: 10px;">
                <div class="col-md-4">
                    <h5>Detail Transaksi</h5>
                    <p>No Pesanan: <?php echo $rowTransaksi['id_transaksi']; ?></p>
                    <p>Tanggal: <?php echo $rowTransaksi['tanggal_transaksi']; ?></p>
                    <p>Total Bayar: <?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></p>
                    <!-- Sisipkan detail transaksi lainnya di sini -->
                </div>
                <div class="col-md-4">
                    <h5>Pelanggan</h5>
                    <p>Nama: <?php echo $rowPelanggan['nama_pelanggan']; ?></p>
                    <p>No Telp: <?php echo $rowPelanggan['no_telp']; ?></p>
                    <p>Email: <?php echo $rowPelanggan['email']; ?></p>
                    <!-- Sisipkan detail transaksi lainnya di sini -->
                </div>
                <div class="col-md-4">
                    <h5>Pengiriman</h5>
                    <p>Ongkos Kirim: <?php echo 'Rp. ' . number_format($rowTransaksi['ongkir'], 0, ',', '.'); ?></p>
                    <p>Ekspedisi: <?php echo $rowTransaksi['ekspedisi']; ?></p>
                    <p>Alamat: 
                        <?php echo $rowTransaksi['provinsi']; ?>
                        <?php echo $rowTransaksi['distrik']; ?>
                        <?php echo $rowTransaksi['alamat_pengiriman']; ?>
                    </p>
                    <p>Catatan: <?php echo $rowTransaksi['catatan']; ?></p>
                    <!-- Sisipkan detail transaksi lainnya di sini -->
                </div>
            </div>
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Berat</th>
                        <th>Jumlah</th>
                        <th>Subberat</th>
                        <th>Subtotal</th>
                        <th>Ongkir</th>
                        <th>Total Bayar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Inisialisasi variabel nomor
                    $nomor = 1;
                    
                    while ($rowPembelianProduk = $resultPembelianProduk->fetch_assoc()) : ?>
                    <tr>
                        <!-- Nomor -->
                        <td><?php echo $nomor++; ?></td>
                        <td style="display: none;"><input type="hidden" name="id_produk[]" value="<?php echo $rowPembelianProduk['id_produk']; ?>"></td>
                        <td><?php echo $rowPembelianProduk['nama_produk']; ?></td>
                        <td><?php echo 'Rp. ' . number_format($rowPembelianProduk['harga_produk'], 0, ',', '.'); ?></td>
                        <td><?php echo $rowPembelianProduk['berat_produk']. " gr"; ?></td>
                        <td><?php echo $rowPembelianProduk['jumlah']; ?></td>
                        <td><?php echo $rowPembelianProduk['subberat']. " gr"; ?></td>
                        <td><?php echo 'Rp. ' .number_format($rowPembelianProduk['subharga'], 0, ',', '.'); ?></td>
                        <td> <?php echo 'Rp. ' . number_format($rowTransaksi['ongkir'], 0, ',', '.'); ?></td>
                        <td><?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- End of Content Wrapper -->
</div>
<!-- End of Page Wrapper -->

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>
<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
</body>
</html>