<?php
include 'koneksi.php';

// Periksa apakah parameter id telah diterima
if (isset($_GET['id'])) {
    $id_transaksi = $_GET['id'];

    // Query untuk menghapus data terkait dari tabel tb_pembelian_produk
    $query_hapus_pembelian_produk = "DELETE FROM tb_pembelian_produk WHERE id_transaksi = '$id_transaksi'";
    
    // Jalankan query penghapusan data terkait
    if (mysqli_query($koneksi, $query_hapus_pembelian_produk)) {
        // Jika penghapusan data terkait berhasil, lanjutkan dengan menghapus data dari tabel tb_transaksi
        $query_hapus_transaksi = "DELETE FROM tb_transaksi WHERE id_transaksi = '$id_transaksi'";
        
        if (mysqli_query($koneksi, $query_hapus_transaksi)) {
            // Jika penghapusan berhasil, redirect kembali ke halaman transaksilangsung.php
            header("Location: transaksitidaklangsung.php?message=success");
            exit();
        } else {
            // Jika terjadi kesalahan saat menghapus data dari tabel tb_transaksi, tampilkan pesan kesalahan
            echo "Error: " . $query_hapus_transaksi . "<br>" . mysqli_error($koneksi);
        }
    } else {
        // Jika terjadi kesalahan saat menghapus data dari tabel tb_pembelian_produk, tampilkan pesan kesalahan
        echo "Error: " . $query_hapus_pembelian_produk . "<br>" . mysqli_error($koneksi);
    }
} else {
    // Jika parameter id_transaksi tidak diterima, tampilkan pesan kesalahan
    echo "Parameter id_transaksi tidak ditemukan.";
}
?>
