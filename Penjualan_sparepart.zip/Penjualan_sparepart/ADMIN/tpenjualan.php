<?php

include 'koneksi.php';

$id_penjualan = $_POST['id_penjualan'];
$nama_pelanggan = $_POST['nama_pelanggan'];
$nama_barang = $_POST['nama_barang'];
$alamat_pengiriman = $_POST['alamat_pengiriman'];
$tanggal = $_POST['tanggal'];
$keterangan = $_POST['keterangan'];


if(empty($id_penjualan) || empty($nama_pelanggan) || empty($nama_barang) || empty($alamat_pengiriman) || empty($tanggal) || empty($keterangan)) {
    if(empty($id_penjualan)) {
        echo "id Penjualan Tidak Boleh Kosong<br>";
    }
    if(empty($nama_pelanggan)) {
        echo "Nama Pelanggan Tidak Boleh Kosong<br>";
    }
    if(empty($nama_barang)) {
        echo "Nama Barang Tidak Boleh Kosong<br>";
    }
    if(empty($alamat_pengiriman)) {
        echo "Alamat Pengiriman Tidak Boleh Kosong<br>";
    }
    if(empty($tanggal)) {
        echo "Tanggal Tidak Boleh Kosong<br>";
    }
    if(empty($keterangan)) {
        echo "Keterangan Tidak Boleh Kosong<br>";
    } 
} else {
    $query = "INSERT INTO tabel_penjualan VALUES ('$id_penjualan', '$nama_pelanggan', '$nama_barang', '$alamat_pengiriman', '$tanggal', '$keterangan')";

    if (mysqli_query($koneksi, $query)) {
        echo "Data telah ditambahkan";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
}

mysqli_close($koneksi);
header("location:penjualan.php");
?>
