<?php
// Include file koneksi database
include 'koneksi.php'; // Sesuaikan dengan nama file koneksi Anda

// Periksa apakah nilai $_GET['id'] telah diset
$idTransaksi = isset($_GET['id']) ? $_GET['id'] : null;

// Pastikan $idTransaksi tidak null sebelum mengambil data dari database
if ($idTransaksi) {
    // Query untuk mengambil data transaksi
    $queryTransaksi = "SELECT * FROM tb_transaksi WHERE id_transaksi = ?";
    $stmtTransaksi = $koneksi->prepare($queryTransaksi);
    $stmtTransaksi->bind_param("i", $idTransaksi);
    $stmtTransaksi->execute();
    $resultTransaksi = $stmtTransaksi->get_result();
    $rowTransaksi = $resultTransaksi->fetch_assoc();

    // Ambil ID pelanggan dari transaksi
    $idPelanggan = $rowTransaksi['id_pelanggan'];

    // Query untuk mengambil data pelanggan berdasarkan ID pelanggan dari transaksi
    $queryPelanggan = "SELECT nama_pelanggan, no_telp, email FROM tabel_pelanggan WHERE id_pelanggan = ?";
    $stmtPelanggan = $koneksi->prepare($queryPelanggan);
    $stmtPelanggan->bind_param("i", $idPelanggan);
    $stmtPelanggan->execute();
    $resultPelanggan = $stmtPelanggan->get_result();
    $rowPelanggan = $resultPelanggan->fetch_assoc();

    // Query untuk mengambil data pembelian produk
    $queryPembelianProduk = "SELECT * FROM tb_pembelian_produk WHERE id_transaksi = ?";
    $stmtPembelianProduk = $koneksi->prepare($queryPembelianProduk);
    $stmtPembelianProduk->bind_param("i", $idTransaksi);
    $stmtPembelianProduk->execute();
    $resultPembelianProduk = $stmtPembelianProduk->get_result();
} else {
    // Jika $idTransaksi null, maka berikan pesan kesalahan atau redirect ke halaman lain
    echo "ID Transaksi tidak valid atau tidak ditemukan.";
    exit; // Hentikan eksekusi skrip
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Detail Transaksi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: auto;
            border: 1px solid #ddd; /* Tambahkan border ke container */
            padding: 20px;
        }
        .title {
            text-align: center;
            margin-bottom: 20px;
            font-size: 20px;
        }
        .info {
            margin-bottom: 10px;
        }
        .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .column {
            width: 30%;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            border: 1px solid #ddd; /* Tambahkan border ke seluruh elemen th dan td */
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2;
        }
        .no-print {
            display: none;
        }
        @media print {
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Detail Bengkel dan Tanggal -->
    <div class="title">
        <h2>Teguh Raya Motor</h2>
        <p>TEGUH RAYA MOTOR 1, Bedaro Rampak, Kec. Tebo Tengah, Kabupaten Tebo, Jambi 37573</p>
        <p>Tanggal: <?php echo date('Y-m-d'); ?></p>
    </div>

    <!-- Detail Transaksi -->
    <div class="row">
        <div class="column">
            <h3>Detail Transaksi</h3>
            <p>No Pesanan: <?php echo $rowTransaksi['id_transaksi']; ?></p>
            <p>Tanggal: <?php echo $rowTransaksi['tanggal_transaksi']; ?></p>
            <p>Total Bayar: <?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></p>
        </div>
        <div class="column">
            <h3>Pelanggan</h3>
            <p>Nama: <?php echo $rowPelanggan['nama_pelanggan']; ?></p>
            <p>No Telp: <?php echo $rowPelanggan['no_telp']; ?></p>
            <p>Email: <?php echo $rowPelanggan['email']; ?></p>
        </div>
        <div class="column">
            <h3>Pengiriman</h3>
            <p>Ongkos Kirim: <?php echo 'Rp. ' . number_format($rowTransaksi['ongkir'], 0, ',', '.'); ?></p>
            <p>Ekspedisi: <?php echo $rowTransaksi['ekspedisi']; ?></p>
            <p>Alamat: 
                <?php echo $rowTransaksi['provinsi']; ?>
                <?php echo $rowTransaksi['distrik']; ?>
                <?php echo $rowTransaksi['alamat_pengiriman']; ?>
            </p>
            <p>Catatan: <?php echo $rowTransaksi['catatan']; ?></p>
        </div>
    </div>
    <!-- Tabel Pembelian -->
    <table class="table">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
                <th>Total Bayar</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            // Inisialisasi variabel nomor
            $nomor = 1;
            
            while ($rowPembelianProduk = $resultPembelianProduk->fetch_assoc()) : ?>
            <tr>
                <!-- Nomor -->
                <td><?php echo $nomor++; ?></td>
                <td style="display: none;"><input type="hidden" name="id_produk[]" value="<?php echo $rowPembelianProduk['id_produk']; ?>"></td>
                <td><?php echo $rowPembelianProduk['nama_produk']; ?></td>
                <td><?php echo 'Rp. ' . number_format($rowPembelianProduk['harga_produk'], 0, ',', '.'); ?></td>
                <td><?php echo $rowPembelianProduk['jumlah']; ?></td>
                <td><?php echo 'Rp. ' .number_format($rowPembelianProduk['subharga'], 0, ',', '.'); ?></td>
                <td><?php echo 'Rp. ' . number_format($rowTransaksi['total_bayar'], 0, ',', '.'); ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>
    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
    window.print();
</script>
</body>
</html>
