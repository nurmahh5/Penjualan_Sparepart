<?php
// Include file koneksi.php
include 'koneksi.php';

// Periksa apakah parameter id_pelanggan telah dikirimkan melalui URL
if(isset($_GET['id'])) {
    // Tangkap id_pelanggan dari parameter URL
    $id_pelanggan = $_GET['id'];

    // Query untuk menghapus data pelanggan berdasarkan id_pelanggan
    $query = "DELETE FROM tabel_pelanggan WHERE id_pelanggan = ?";

    // Persiapkan statement
    $stmt = mysqli_prepare($koneksi, $query);

    // Bind parameter
    mysqli_stmt_bind_param($stmt, 'i', $id_pelanggan);

    // Lakukan penghapusan data
    if(mysqli_stmt_execute($stmt)) {
        // Jika berhasil dihapus, redirect ke halaman pelanggan.php
        header("Location: pelanggan.php");
        exit();
    } else {
        // Jika terjadi error, tampilkan pesan error
        echo "Error: " . mysqli_error($koneksi);
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
} else {
    // Jika parameter id_pelanggan tidak diberikan, tampilkan pesan error
    echo "ID pelanggan tidak diberikan.";
}

// Tutup koneksi database
mysqli_close($koneksi);
?>
