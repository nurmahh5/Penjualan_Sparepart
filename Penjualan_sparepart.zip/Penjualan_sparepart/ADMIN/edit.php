<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_produk = $_POST['id_produk'];
    $part_number = $_POST['part_number'];
    $nama_produk = $_POST['nama_produk'];
    $deskripsi = $_POST['deskripsi'];
    $kategori_produk = $_POST['kategori_produk'];
    $harga_produk = $_POST['harga_produk'];
    $jumlah_stok = $_POST['jumlah_stok'];
    $berat_produk = $_POST['berat_produk'];
    $gambar_lama = $_POST['gambar_lama'];

    if (isset($_FILES['userfile']) && $_FILES['userfile']['error'] == UPLOAD_ERR_OK) {
        $filename = basename($_FILES['userfile']['name']);
        $target_dir = "uploads/";
        $target_file = $target_dir . $filename;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
        // Check if the uploaded file is an image.
        $check = getimagesize($_FILES["userfile"]["tmp_name"]);
        if ($check === false) {
            echo "File is not an image.";
            exit();
        }
    
        // Allow certain file formats.
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            exit();
        }
    
        // Check if the uploaded file exists.
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            exit();
        }
    
        // Check file size.
        if ($_FILES["userfile"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            exit();
        }
    
        // Move the uploaded file to the target directory.
        if (!move_uploaded_file($_FILES["userfile"]["tmp_name"], $target_file)) {
            echo "Sorry, there was an error uploading your file.";
            exit();
        }
    
        // File uploaded successfully.
        $filepath = $target_file;
    } else {
        // Get the existing filepath from the database.
        $query = "SELECT gambar_produk FROM tb_sparepart WHERE id_produk = ?";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, 'i', $id_produk);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $gambar_produk);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    
        $filepath = $gambar_produk;
    } 
    // Periksa apakah gambar diunggah dengan benar
   
    // Kueri UPDATE
    $query = "UPDATE tb_sparepart 
              SET part_number=?, 
                  nama_produk=?, 
                  deskripsi=?, 
                  kategori_produk=?, 
                  harga_produk=?, 
                  jumlah_stok=?, 
                  gambar_produk=? 
                  berat_produk=?, 
              WHERE id_produk=?";
    $stmt = mysqli_prepare($koneksi, $query);

    if (!$stmt) {
        echo "Error preparing statement: " . mysqli_error($koneksi);
        exit();
    }

    mysqli_stmt_bind_param($stmt, 'ssssiiis', $part_number, $nama_produk, $deskripsi, $kategori_produk, $harga_produk, $jumlah_stok, $gambar_produk, $berat_produk, $id_produk);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: barang.php");
        exit();
    } else {
        echo "Error executing statement: " . mysqli_stmt_error($stmt);
    }

    mysqli_stmt_close($stmt);
}
if (isset($_GET['id'])) {
    $id_produk = $_GET['id'];
    $query = "SELECT * FROM tb_sparepart WHERE id_produk = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id_produk);

    if (mysqli_stmt_execute($stmt)) {
        $result = mysqli_stmt_get_result($stmt);
        if ($row = mysqli_fetch_assoc($result)) {
            $id_produk = $row['id_produk'];
            $part_number = $row['part_number'];
            $nama_produk = $row['nama_produk'];
            $deskripsi = $row['deskripsi'];
            $kategori_produk = $row['kategori_produk'];
            $harga_produk = $row['harga_produk'];
            $jumlah_stok = $row['jumlah_stok'];
            $gambar_produk = $row['gambar_produk'];
            $berat_produk = $row['berat_produk'];
        } else {
            echo "Data tidak ditemukan.";
            exit();
        }
    } else {
        echo "Error: " . mysqli_error($koneksi);
        exit();
    }

    mysqli_stmt_close($stmt);
} else {
    echo "ID barang tidak diberikan.";
    exit();
}

mysqli_close($koneksi);
?>




<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Admin</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-icon rotate-n-15">
                </div>
                <div class="sidebar-brand-text mx-3">TEGUH RAYA MOTOR</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>DASHBOARD</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
        aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-fw fa-folder"></i>
        <span>MASTER DATA</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="pelanggan.php">Data Pelanggan</a>
            <a class="collapse-item" href="barang.php">Data Barang</a>
        </div>
    </div>
</li>

<!-- Nav Item - Utilities Collapse Menu -->
<li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
        aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>TRANSAKSI</span>
    </a>
    <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
        data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="transaksilangsung.php">Transaksi Langsung</a>
            <a class="collapse-item" href="transaksitidaklangsung.php">Transaksi Tidak Langsung</a>
        </div>
    </div>
</li>
<li class="nav-item">
    <a class="nav-link collapsed" href="laporan.php" ata-target="#collapseUtilities"
        aria-expanded="true" aria-controls="collapseUtilities">
        <i class="fas fa-fw fa-file"></i>
        <span>LAPORAN</span>
    </a>
</li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <h1 class="h3 mb-4 text-gray-800">Edit Data Barang</h1>
                </nav>            
                <body id="page-top">
<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <!-- Sidebar content here -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <!-- Topbar content here -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

            <div class="card shadow mb-4">
                        <div class="card-header py-3">
                <!-- Form Edit Data Barang -->
                <form action="edit.php" method="post" enctype="multipart/form-data">
                <div class="row mb-3">
                <input type="hidden" name="id_produk" value="<?php echo $id_produk; ?>">
    <label for="inputEmail3" class="col-sm-2 col-form-label">Nomor Part</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputEmail3" name="part_number" value="<?php echo $part_number; ?>">
    </div>
</div>
<div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Nama Produk</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" name="nama_produk" value="<?php echo $nama_produk; ?>">
    </div>
</div>
<div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Deskripsi</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" name="deskripsi" value="<?php echo $deskripsi; ?>">
    </div>
</div>
<!-- Tambahkan bidang kategori di sini -->
<div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Kategori Produk</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" name="kategori_produk" value="<?php echo $kategori_produk; ?>">
    </div>
</div>
<div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Harga</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" name="harga_produk" value="<?php echo $harga_produk; ?>">
    </div>
</div>
<div class="row mb-3">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Stok</label>
    <div class="col-sm-10">
        <input type="text" class="form-control" id="inputPassword3" name="jumlah_stok" value="<?php echo $jumlah_stok; ?>">
    </div>
</div>
<div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Berat</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" id="inputPassword3" name="berat_produk"  value="<?php echo $berat_produk; ?>">
                    </div>
                </div>
<div class="row mb-3">
    <label for="vol-gambar" class="col-sm-2 col-form-label">Gambar</label>
    <div class="col-sm-10">
        <input type="file" id="val-gambar" name="gambar" class="form-control-file">
        <?php if (!empty($gambar_produk)): ?>
            <img src="<?php echo $gambar_produk; ?>" alt="Gambar Produk" style="max-width: 200px; margin-top: 10px;">
        <?php endif; ?>
    </div>
</div>


                <div class="form-group row">
                    <div class="col-sm-10"> 
                <button type="submit" class="btn btn-danger" name="proses">Update Data</button>
                </form>
                </div> 
                </div>
          

                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>